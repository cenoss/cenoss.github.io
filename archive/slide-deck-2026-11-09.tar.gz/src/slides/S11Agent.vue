<script setup lang="ts">
import SlideShell from '../components/SlideShell.vue'
import ThreeScene from '../components/ThreeScene.vue'
import { scenes } from '../scenes'
import { useI18n } from '../composables/i18n'
const { t } = useI18n()
const verbs = ['a1', 'a2', 'a3', 'a4', 'a5']
const rules = ['rule1', 'rule2', 'rule3']
</script>

<template>
  <SlideShell kicker="s11.kicker" title="s11.title">
    <div class="agent">
      <ol v-stagger class="verbs">
        <li v-for="v in verbs" :key="v">
          <h3>{{ t(`s11.${v}_h`) }}</h3>
          <p>{{ t(`s11.${v}`) }}</p>
        </li>
      </ol>
      <aside class="rules">
        <h3>{{ t('s11.rules_h') }}</h3>
        <ul>
          <li v-for="r in rules" :key="r">{{ t(`s11.${r}`) }}</li>
        </ul>
      </aside>
    </div>
    <ThreeScene :scene="scenes.s11" :style="{ right: 0, bottom: 0, width: '32cqw', height: '13cqw' }" />
  </SlideShell>
</template>

<style scoped>
.agent {
  height: 100%;
  display: grid;
  grid-template-columns: 1.4fr 0.8fr;
  column-gap: 3cqw;
  align-content: start;
}
.verbs {
  display: grid;
  row-gap: 0.9cqw;
}
.verbs li {
  display: grid;
  grid-template-columns: 9cqw 1fr;
  column-gap: 1.2cqw;
  align-items: baseline;
  padding-bottom: 0.9cqw;
  border-bottom: 1px solid var(--line);
}
.verbs h3 {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: var(--t-h3);
}
.verbs p {
  font-size: 1.45cqw;
  line-height: 1.4;
}
.rules {
  align-self: start;
  animation: rise 600ms var(--ease-out) 1000ms both;
  background: var(--key);
  color: var(--stock);
  padding: 1.4cqw 1.6cqw;
  display: grid;
  align-content: start;
  row-gap: 1cqw;
}
.rules h3 {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: var(--t-h3);
}
.rules li {
  font-size: 1.45cqw;
  line-height: 1.4;
}
.rules li + li {
  margin-top: 0.8cqw;
  padding-top: 0.8cqw;
  border-top: 1px solid rgba(228, 230, 226, 0.2);
}
</style>
