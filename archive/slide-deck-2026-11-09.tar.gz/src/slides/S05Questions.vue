<script setup lang="ts">
import SlideShell from '../components/SlideShell.vue'
import ThreeScene from '../components/ThreeScene.vue'
import { scenes } from '../scenes'
import { useI18n } from '../composables/i18n'
const { t } = useI18n()
const aqs = [
  { n: 1, lens: 'coop' },
  { n: 2, lens: 'coop' },
  { n: 3, lens: 'dyn' },
  { n: 4, lens: 'plat' },
  { n: 5, lens: 'plat' },
  { n: 6, lens: 'plat' },
]
</script>

<template>
  <SlideShell kicker="s5.kicker" title="s5.title">
    <ul v-stagger class="aqs">
      <li v-for="aq in aqs" :key="aq.n" class="aq" :class="`lens-${aq.lens}`">
        <p class="aq-head">
          <span class="aq-n">AQ{{ aq.n }}</span>
          <span class="aq-tag">{{ t(`s5.aq${aq.n}_tag`) }}</span>
        </p>
        <p class="aq-text">{{ t(`s5.aq${aq.n}`) }}</p>
      </li>
    </ul>
    <ThreeScene :scene="scenes.s5" :opacity="0.3" :style="{ inset: 0 }" />
  </SlideShell>
</template>

<style scoped>
.aqs {
  height: 100%;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-template-rows: repeat(2, 1fr);
  gap: 1.2cqw 1.6cqw;
}
.aq {
  border-top: 0.4cqw solid var(--lens);
  padding-top: 0.8cqw;
  display: grid;
  align-content: start;
  row-gap: 0.6cqw;
  --lens: var(--key);
  --lens-ink: var(--key);
}
.lens-coop {
  --lens: var(--producer);
  --lens-ink: var(--producer-ink);
}
.lens-plat {
  --lens: var(--gateway);
  --lens-ink: var(--gateway-ink);
}
.aq-head {
  display: flex;
  align-items: baseline;
  gap: 0.8cqw;
}
.aq-n {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: var(--t-h3);
  color: var(--lens-ink);
}
.aq-tag {
  font-size: var(--t-kicker);
  color: var(--muted);
}
.aq-text {
  font-size: 1.3cqw;
  line-height: 1.38;
}
</style>
