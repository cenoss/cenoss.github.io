import { describe, expect, test } from 'vitest'
import { mount } from '@vue/test-utils'
import { defineComponent, h, withDirectives } from 'vue'
import { stagger } from '../src/directives/stagger'

describe('v-stagger', () => {
  test('numbers each child with a --i custom property in order', () => {
    const Comp = defineComponent({
      render() {
        return withDirectives(h('ul', [h('li'), h('li'), h('li')]), [[stagger]])
      },
    })
    const wrapper = mount(Comp)
    const items = wrapper.findAll('li')
    expect(items.map((li) => (li.element as HTMLElement).style.getPropertyValue('--i'))).toEqual(['0', '1', '2'])
  })

  test('adds the stagger class to the container', () => {
    const Comp = defineComponent({
      render() {
        return withDirectives(h('div', [h('p')]), [[stagger]])
      },
    })
    const wrapper = mount(Comp)
    expect(wrapper.classes()).toContain('stagger')
  })
})
