import { ref } from 'vue'

export type Lang = 'en' | 'zh-TW'
export type Messages = Record<Lang, Record<string, string>>

interface StorageLike {
  getItem(key: string): string | null
  setItem(key: string, value: string): void
}

const STORAGE_KEY = 'lang'
const LANGS: Lang[] = ['en', 'zh-TW']

function isLang(v: unknown): v is Lang {
  return typeof v === 'string' && (LANGS as string[]).includes(v)
}

function restore(storage: StorageLike | null): Lang {
  try {
    const saved = storage?.getItem(STORAGE_KEY)
    return isLang(saved) ? saved : 'en'
  } catch {
    return 'en'
  }
}

export function useLang(messages: Messages, storage: StorageLike | null) {
  const lang = ref<Lang>(restore(storage))

  const t = (key: string): string => messages[lang.value][key] ?? key
  const set = (l: Lang) => {
    lang.value = l
    try {
      storage?.setItem(STORAGE_KEY, l)
    } catch {
      /* storage blocked: language still works for this session */
    }
  }
  const toggle = () => set(lang.value === 'en' ? 'zh-TW' : 'en')

  return { lang, t, set, toggle }
}
