<script setup lang="ts">
import SlideShell from '../components/SlideShell.vue'
import ThreeScene from '../components/ThreeScene.vue'
import { scenes } from '../scenes'
import { useI18n } from '../composables/i18n'
const { t } = useI18n()
const teams = ['t1', 't2', 't3']
const milestones = ['m1', 'm2', 'm3', 'm4', 'm5', 'm6']
const grades = ['g1', 'g2', 'g3', 'g4', 'g5']
</script>

<template>
  <SlideShell kicker="s13.kicker" title="s13.title">
    <div class="team">
      <ul v-stagger class="pairs">
        <li v-for="p in teams" :key="p">
          <h3>{{ t(`s13.${p}_h`) }}</h3>
          <p class="names">{{ t('s13.names') }}</p>
          <p>{{ t(`s13.${p}`) }}</p>
        </li>
      </ul>
      <ol v-stagger class="track">
        <li v-for="m in milestones" :key="m" :class="{ now: m === 'm2' }">
          <span class="tick" />
          <span class="week">{{ t(`s13.${m}_w`) }}</span>
          <span class="what">{{ t(`s13.${m}`) }}</span>
        </li>
      </ol>
      <div class="grades">
        <h3>{{ t('s13.g_h') }}</h3>
        <ul>
          <li v-for="g in grades" :key="g">{{ t(`s13.${g}`) }}</li>
        </ul>
      </div>
    </div>
    <ThreeScene :scene="scenes.s13" :opacity="0.3" :style="{ right: 0, top: 0, bottom: 0, width: '46cqw' }" />
  </SlideShell>
</template>

<style scoped>
.team {
  height: 100%;
  display: grid;
  grid-template-rows: auto auto 1fr;
  row-gap: 2.6cqw;
  align-content: start;
}
.pairs {
  --stagger-step: 140ms;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  column-gap: 2cqw;
}
.pairs li {
  display: grid;
  row-gap: 0.3cqw;
  padding-top: 0.7cqw;
  border-top: 0.4cqw solid var(--key);
  font-size: 1.35cqw;
  line-height: 1.35;
}
h3 {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: var(--t-h3);
}
.names {
  color: var(--muted);
}
.track {
  --stagger-base: 1000ms;
  --stagger-step: 130ms;
  display: grid;
  grid-template-columns: repeat(6, 1fr);
  position: relative;
  padding-top: 0.9cqw;
}
.track::before {
  content: '';
  position: absolute;
  left: 0;
  right: 0;
  top: 0.9cqw;
  height: 1px;
  background: var(--line);
  transform-origin: left;
  animation: draw 900ms var(--ease-out) 900ms both;
}
.track li {
  display: grid;
  row-gap: 0.3cqw;
  font-size: 1.2cqw;
}
.tick {
  width: 0.9cqw;
  height: 0.9cqw;
  border-radius: 50%;
  background: var(--stock);
  border: 0.18cqw solid var(--muted);
  margin-top: -1.35cqw;
}
.track li.now .tick {
  background: var(--key);
  border-color: var(--key);
  animation: pulse 900ms ease-out 2000ms 1 both;
}
.track li.now .week,
.track li.now .what {
  color: var(--key);
  font-weight: 600;
}
.week {
  color: var(--muted);
}
.grades {
  animation: rise 600ms var(--ease-out) 1900ms both;
  display: grid;
  grid-template-columns: 14cqw 1fr;
  column-gap: 2cqw;
  align-items: start;
}
.grades ul {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0.5cqw 2cqw;
  font-size: 1.35cqw;
  line-height: 1.35;
}
.grades li {
  padding-left: 0.9cqw;
  border-left: 0.18cqw solid var(--muted);
}
</style>
