import { onBeforeUnmount, onMounted, ref } from 'vue'

/** Ease-out cubic from `from` to `target` as progress runs 0..1. */
export function interpolate(target: number, progress: number, from = 0): number {
  const p = Math.min(Math.max(progress, 0), 1)
  if (p === 1) return target
  const eased = 1 - Math.pow(1 - p, 3)
  return from + (target - from) * eased
}

export interface CountUpOptions {
  from?: number
  delayMs?: number
}

function prefersReducedMotion(): boolean {
  return typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches
}

export function useCountUp(target: number, durationMs = 1200, decimals = 0, opts: CountUpOptions = {}) {
  const from = opts.from ?? 0
  const delayMs = opts.delayMs ?? 0
  const value = ref(from)
  const text = ref(from.toFixed(decimals))
  let timer: ReturnType<typeof setTimeout> | undefined

  const set = (v: number) => {
    value.value = v
    text.value = v.toFixed(decimals)
  }

  onMounted(() => {
    if (prefersReducedMotion()) {
      set(target)
      return
    }
    timer = setTimeout(() => {
      const start = performance.now()
      const step = (now: number) => {
        const progress = (now - start) / durationMs
        set(interpolate(target, progress, from))
        if (progress < 1) requestAnimationFrame(step)
      }
      requestAnimationFrame(step)
    }, delayMs)
  })
  onBeforeUnmount(() => clearTimeout(timer))

  return { value, text }
}
