<script setup lang="ts">
import { computed } from 'vue'
import { useI18n } from '../composables/i18n'
import { useCountUp } from '../composables/useCountUp'

const props = withDefaults(
  defineProps<{
    /** numeric value to count up to; omit when `text` is given */
    value?: number
    decimals?: number
    suffix?: string
    /** literal display text instead of a number */
    text?: string
    /** translation key for the label under the number */
    label: string
    tone?: 'producer' | 'gateway' | 'key'
  }>(),
  { decimals: 0, suffix: '', tone: 'key' },
)

const { t } = useI18n()
const count = useCountUp(props.value ?? 0, 1400, props.decimals)
const display = computed(() => (props.text !== undefined ? props.text : count.text.value + props.suffix))
</script>

<template>
  <div class="stat" :class="`tone-${tone}`">
    <p class="stat-value">{{ display }}</p>
    <p class="stat-label">{{ t(label) }}</p>
  </div>
</template>

<style scoped>
.stat {
  display: grid;
  align-content: start;
  row-gap: 0.5cqw;
  padding-top: 0.9cqw;
  border-top: 0.5cqw solid var(--key);
}
.tone-producer {
  border-top-color: var(--producer);
}
.tone-producer .stat-value {
  color: var(--producer);
}
.tone-gateway {
  border-top-color: var(--gateway);
}
.tone-gateway .stat-value {
  color: var(--gateway-ink);
}
.stat-value {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: var(--t-stat);
  line-height: 1;
  font-variant-numeric: tabular-nums;
  letter-spacing: -0.01em;
}
.stat-label {
  font-size: var(--t-body);
  line-height: 1.3;
  color: var(--muted);
  max-width: 22ch;
}
</style>
