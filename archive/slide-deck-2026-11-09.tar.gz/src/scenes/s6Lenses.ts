import * as THREE from 'three'
import { disposeGroup, solid, type SceneFactory } from './helpers'

/** Three course lenses as rings turning on different axes. */
export const s6Lenses: SceneFactory = ({ scene, camera, palette }) => {
  const group = new THREE.Group()
  const colors = [palette.producer, palette.key, palette.gateway]
  const rings = colors.map((c, i) => {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(1.7 - i * 0.25, 0.05, 10, 100), solid(c, 0.9))
    group.add(ring)
    return ring
  })
  scene.add(group)
  camera.position.set(0, 0, 6.5)
  camera.lookAt(0, 0, 0)

  return {
    update(t) {
      rings[0].rotation.set(t * 0.5, t * 0.3, 0)
      rings[1].rotation.set(0, t * 0.45, t * 0.35)
      rings[2].rotation.set(t * 0.35, 0, t * 0.5)
      group.rotation.y = Math.sin(t * 0.2) * 0.3
    },
    dispose: () => disposeGroup(scene, group),
  }
}
