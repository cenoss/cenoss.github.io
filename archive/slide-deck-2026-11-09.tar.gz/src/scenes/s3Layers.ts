import * as THREE from 'three'
import { disposeGroup, rand, solid, type SceneFactory } from './helpers'

/** News flows upward from producer cubes to gateway spheres; one block spans both layers. */
export const s3Layers: SceneFactory = ({ scene, camera, palette }) => {
  const group = new THREE.Group()
  for (let i = 0; i < 10; i++) {
    const cube = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.35, 0.35), solid(palette.producer, 0.9))
    cube.position.set((i - 4.5) * 0.55, -1.4, (rand(i) - 0.5) * 1.2)
    group.add(cube)
  }
  for (let i = 0; i < 3; i++) {
    const s = new THREE.Mesh(new THREE.SphereGeometry(0.45, 20, 14), solid(palette.gateway, 0.95))
    s.position.set((i - 1) * 1.9, 1.5, 0)
    group.add(s)
  }
  const ettoday = new THREE.Mesh(new THREE.BoxGeometry(0.45, 3.3, 0.45), solid(palette.producer))
  ettoday.position.set(-3.1, 0.05, 0)
  group.add(ettoday)

  const count = 140
  const pos = new Float32Array(count * 3)
  const seed = Array.from({ length: count }, (_, i) => ({ x: (rand(i * 3) - 0.5) * 5.4, z: (rand(i * 3 + 1) - 0.5) * 1.2, phase: rand(i * 3 + 2) }))
  const geo = new THREE.BufferGeometry()
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3))
  const points = new THREE.Points(geo, new THREE.PointsMaterial({ color: palette.key, size: 0.07, transparent: true, opacity: 0.85 }))
  group.add(points)
  scene.add(group)
  camera.position.set(0, 0.4, 8)
  camera.lookAt(0, 0, 0)

  return {
    update(t) {
      group.rotation.y = Math.sin(t * 0.25) * 0.4
      for (let i = 0; i < count; i++) {
        const p = (t * 0.22 + seed[i].phase) % 1
        pos[i * 3] = seed[i].x
        pos[i * 3 + 1] = -1.2 + p * 2.5
        pos[i * 3 + 2] = seed[i].z
      }
      geo.attributes.position.needsUpdate = true
    },
    dispose: () => disposeGroup(scene, group),
  }
}
