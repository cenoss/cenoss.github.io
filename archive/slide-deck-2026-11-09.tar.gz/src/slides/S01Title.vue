<script setup lang="ts">
import { useI18n } from '../composables/i18n'
const { t } = useI18n()
</script>

<template>
  <section class="slide hero">
    <p class="kicker">{{ t('s1.kicker') }}</p>
    <div class="hero-main">
      <div v-stagger class="hero-text">
        <h1 class="hero-title">{{ t('s1.title') }}</h1>
        <p class="hero-sub">{{ t('s1.subtitle') }}</p>
      </div>
      <!-- the thesis as two printing plates: they come into register and ETtoday is where both print -->
      <div class="plates" aria-hidden="true">
        <div class="plate plate-producer"><span>{{ t('s3.layer1') }}</span></div>
        <div class="plate plate-gateway"><span>{{ t('s3.layer2') }}</span></div>
        <div class="overprint"><span>ETtoday</span></div>
      </div>
    </div>
    <ul v-stagger class="hero-meta">
      <li>{{ t('s1.track') }}</li>
      <li>{{ t('s1.group') }}</li>
      <li>{{ t('s1.members') }}</li>
      <li>{{ t('s1.date') }}</li>
    </ul>
  </section>
</template>

<style scoped>
.hero {
  grid-template-rows: auto 1fr auto;
}
.hero-main {
  display: grid;
  grid-template-columns: 1fr 34cqw;
  column-gap: 4cqw;
  align-items: center;
}
.hero-text {
  --stagger-base: 200ms;
  --stagger-step: 180ms;
  display: grid;
  row-gap: 1.8cqw;
}
.hero-title {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: var(--t-hero);
  line-height: 1.02;
  letter-spacing: -0.02em;
  max-width: 15ch;
  text-wrap: balance;
}
:lang(zh-TW) .hero-title {
  letter-spacing: 0.02em;
  line-height: 1.15;
}
.hero-sub {
  font-size: var(--t-lead);
  color: var(--muted);
  max-width: 34ch;
  line-height: 1.35;
}

/* plate geometry: two 22×17 plates offset by 12×9, overlapping in a 10×8 block */
.plates {
  position: relative;
  width: 34cqw;
  height: 26cqw;
  --reg: 1100ms;
}
.plate,
.overprint {
  position: absolute;
  width: 22cqw;
  height: 17cqw;
  display: flex;
  padding: 1.1cqw 1.3cqw;
  font-size: var(--t-body);
  font-weight: 600;
  line-height: 1.2;
}
.plate-producer {
  left: 0;
  top: 0;
  background: var(--producer);
  color: #fff;
  animation: register-m var(--reg) var(--ease-out) 300ms both;
}
.plate-gateway {
  right: 0;
  bottom: 0;
  background: var(--gateway);
  color: var(--key);
  align-items: flex-end;
  justify-content: flex-end;
  text-align: right;
  animation: register-c var(--reg) var(--ease-out) 300ms both;
}
.plate span {
  max-width: 9cqw;
}
.overprint {
  left: 12cqw;
  top: 9cqw;
  width: 10cqw;
  height: 8cqw;
  background: var(--overprint);
  color: #fff;
  align-items: center;
  justify-content: center;
  font-family: var(--font-display);
  font-weight: 700;
  font-size: 2.1cqw;
  padding: 0;
  animation: ink-in 500ms ease-out calc(300ms + var(--reg)) both;
}
@keyframes register-m {
  from {
    transform: translate(-2.4cqw, -1.6cqw);
    opacity: 0;
  }
  30% {
    opacity: 1;
  }
  to {
    transform: none;
  }
}
@keyframes register-c {
  from {
    transform: translate(2.4cqw, 1.6cqw);
    opacity: 0;
  }
  30% {
    opacity: 1;
  }
  to {
    transform: none;
  }
}
@keyframes ink-in {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

.hero-meta {
  --stagger-base: 1500ms;
  --stagger-step: 90ms;
  display: flex;
  gap: 3cqw;
  font-size: var(--t-kicker);
  color: var(--muted);
  padding-bottom: 1.4cqw;
  flex-wrap: wrap;
}
.hero-meta li:first-child {
  color: var(--key);
  font-weight: 500;
}
</style>
