<script setup lang="ts">
import SlideShell from '../components/SlideShell.vue'
import StatTile from '../components/StatTile.vue'
import ThreeScene from '../components/ThreeScene.vue'
import { scenes } from '../scenes'
import { useI18n } from '../composables/i18n'
import { useCountUp } from '../composables/useCountUp'
const { t } = useI18n()
const after = useCountUp(385, 1200, 0, { from: 561, delayMs: 1500 })
</script>

<template>
  <SlideShell kicker="s2.kicker" title="s2.title" foot="s2.source">
    <div class="puzzle">
      <div v-stagger class="stats">
        <StatTile :value="38" suffix="%" label="s2.stat1" tone="producer" />
        <StatTile :value="46" suffix="%" label="s2.stat2" tone="producer" />
        <StatTile :value="47.5" :decimals="1" suffix="%" label="s2.stat3" />
        <StatTile :value="36.3" :decimals="1" suffix="%" label="s2.stat4" />
        <StatTile :text="t('s2.stat5_value')" label="s2.stat5" />
      </div>
      <p class="staff">
        <span class="staff-num">561</span>
        <span class="staff-arrow" aria-hidden="true" />
        <span class="staff-num">{{ after.text.value }}</span>
        <span class="staff-text">{{ t('s2.staff') }}</span>
      </p>
    </div>
    <ThreeScene :scene="scenes.s2" :style="{ right: 0, bottom: 0, width: '58cqw', height: '15cqw' }" />
  </SlideShell>
</template>

<style scoped>
.puzzle {
  height: 100%;
  display: grid;
  grid-template-rows: auto auto;
  row-gap: 3.2cqw;
  align-content: start;
}
.stats {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  column-gap: 1.6cqw;
  align-content: start;
}
.staff {
  animation: rise 560ms var(--ease-out) 1200ms both;
  display: flex;
  align-items: center;
  gap: 1.2cqw;
  padding-top: 1.4cqw;
  border-top: 1px solid var(--line);
}
.staff-num {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: 3cqw;
  line-height: 1;
  font-variant-numeric: tabular-nums;
}
.staff-arrow {
  width: 3cqw;
  height: 0.18cqw;
  background: var(--muted);
  position: relative;
}
.staff-arrow::after {
  content: '';
  position: absolute;
  right: -0.1cqw;
  top: 50%;
  width: 0.9cqw;
  height: 0.9cqw;
  border-top: 0.18cqw solid var(--muted);
  border-right: 0.18cqw solid var(--muted);
  transform: translateY(-50%) rotate(45deg);
}
.staff-text {
  margin-left: 1cqw;
  color: var(--muted);
}
</style>
