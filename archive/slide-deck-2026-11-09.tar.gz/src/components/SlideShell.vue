<script setup lang="ts">
import { useI18n } from '../composables/i18n'

defineProps<{
  kicker: string
  title: string
  /** translation key for the small source / footnote line */
  foot?: string
}>()

const { t } = useI18n()
</script>

<template>
  <section class="slide">
    <p class="kicker">{{ t(kicker) }}</p>
    <h2 class="title">{{ t(title) }}</h2>
    <div class="slide-body">
      <slot />
    </div>
    <footer v-if="foot || $slots.foot" class="slide-foot">
      <slot name="foot">{{ foot ? t(foot) : '' }}</slot>
    </footer>
  </section>
</template>

<style>
/* every slide: running head (folio) / headline / body / source line */
.slide {
  position: absolute;
  inset: 0;
  display: grid;
  grid-template-rows: auto auto 1fr auto;
  padding: var(--pad-top) var(--pad-x) var(--pad-bottom);
  row-gap: var(--gap);
}

/* the running head, ruled off like a newspaper folio; DeckChrome puts the page number and language at its right */
.kicker {
  animation: rise 500ms var(--ease-out) both;
  font-size: var(--t-kicker);
  font-weight: 500;
  color: var(--key);
  line-height: 1;
  padding: 0.35cqw 14cqw 0.9cqw 0;
  border-bottom: 0.15cqw solid var(--key);
}

.title {
  animation: rise 640ms var(--ease-out) 120ms both;
  font-family: var(--font-display);
  font-weight: 700;
  font-size: var(--t-title);
  line-height: 1.08;
  letter-spacing: -0.012em;
  max-width: 34ch;
  text-wrap: balance;
  margin-top: 0.6cqw;
}
:lang(zh-TW) .title {
  letter-spacing: 0.02em;
  line-height: 1.2;
}
/* Chinese headlines break at punctuation and spaces, not mid-phrase */
:lang(zh-TW) :is(.title, .hero-title, .close-title) {
  word-break: keep-all;
  overflow-wrap: anywhere;
}

.slide-body {
  position: relative;
  z-index: 0;
  min-height: 0;
  font-size: var(--t-body);
  line-height: 1.4;
}

.slide-foot {
  animation: rise 500ms var(--ease-out) calc(var(--stagger-base) + 760ms) both;
  font-size: var(--t-foot);
  color: var(--muted);
  line-height: 1.4;
  display: flex;
  align-items: center;
  gap: 0.8cqw;
  flex-wrap: wrap;
}
</style>
