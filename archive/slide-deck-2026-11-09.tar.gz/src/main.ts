import { createApp } from 'vue'
import './styles/tokens.css'
import './styles/base.css'
import App from './App.vue'
import { stagger } from './directives/stagger'

createApp(App).directive('stagger', stagger).mount('#app')
