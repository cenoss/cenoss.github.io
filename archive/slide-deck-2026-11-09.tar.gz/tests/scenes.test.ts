import { describe, expect, test } from 'vitest'
import * as THREE from 'three'
import { scenes } from '../src/scenes'
import { PALETTE } from '../src/scenes/helpers'
import { slides } from '../src/content/slides'

describe('scene registry', () => {
  test('covers every slide except the first', () => {
    const expected = slides.slice(1).map((s) => s.id)
    expect(Object.keys(scenes).sort()).toEqual(expected.sort())
  })
})

describe.each(Object.entries(scenes))('scene %s', (_id, factory) => {
  test('builds objects, animates and disposes cleanly', () => {
    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(40, 16 / 9, 0.1, 100)
    const handle = factory({ scene, camera, palette: PALETTE, aspect: 16 / 9 })
    expect(scene.children.length).toBeGreaterThan(0)
    handle.update(0, 0.016)
    handle.update(3.7, 0.016)
    handle.update(12.2, 0.016)
    handle.dispose()
    expect(scene.children.length).toBe(0)
  })
})
