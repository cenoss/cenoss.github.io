<script setup lang="ts">
import SlideShell from '../components/SlideShell.vue'
import ThreeScene from '../components/ThreeScene.vue'
import { scenes } from '../scenes'
import { useI18n } from '../composables/i18n'
const { t } = useI18n()
const lenses = [
  { k: 'l1', tone: 'producer' },
  { k: 'l2', tone: 'paper' },
  { k: 'l3', tone: 'gateway' },
]
</script>

<template>
  <SlideShell kicker="s6.kicker" title="s6.title">
    <div v-stagger class="lenses">
      <article v-for="l in lenses" :key="l.k" class="lens" :class="`tone-${l.tone}`">
        <h3>{{ t(`s6.${l.k}_h`) }}</h3>
        <p class="who">{{ t(`s6.${l.k}_who`) }}</p>
        <p class="text">{{ t(`s6.${l.k}`) }}</p>
      </article>
    </div>
    <ThreeScene :scene="scenes.s6" :style="{ left: 0, right: 0, bottom: 0, height: '20cqw' }" />
  </SlideShell>
</template>

<style scoped>
.lenses {
  --stagger-step: 160ms;
  height: 100%;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  column-gap: 2cqw;
}
.lens {
  display: grid;
  align-content: start;
  row-gap: 0.7cqw;
  padding-top: 1cqw;
  border-top: 0.4cqw solid var(--key);
}
.tone-producer {
  border-top-color: var(--producer);
}
.tone-gateway {
  border-top-color: var(--gateway);
}
h3 {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: 2.4cqw;
  line-height: 1.1;
}
.who {
  font-size: var(--t-kicker);
  color: var(--muted);
}
.text {
  line-height: 1.42;
  margin-top: 0.4cqw;
}
</style>
