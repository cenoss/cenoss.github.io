import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest'
import { defineComponent, h } from 'vue'
import { mount } from '@vue/test-utils'
import { interpolate, useCountUp } from '../src/composables/useCountUp'

describe('interpolate', () => {
  test('returns the target at progress 1', () => {
    expect(interpolate(47.5, 1)).toBe(47.5)
  })

  test('returns zero at progress 0', () => {
    expect(interpolate(47.5, 0)).toBe(0)
  })

  test('is monotonic and eases out', () => {
    const a = interpolate(100, 0.25)
    const b = interpolate(100, 0.5)
    const c = interpolate(100, 0.75)
    expect(a).toBeLessThan(b)
    expect(b).toBeLessThan(c)
    expect(b).toBeGreaterThan(50)
  })

  test('can start from a value other than zero and count down', () => {
    expect(interpolate(385, 0, 561)).toBe(561)
    expect(interpolate(385, 1, 561)).toBe(385)
    expect(interpolate(385, 0.5, 561)).toBeLessThan(561)
    expect(interpolate(385, 0.5, 561)).toBeGreaterThan(385)
  })
})

describe('useCountUp timing', () => {
  let now = 0
  beforeEach(() => {
    vi.useFakeTimers()
    now = 0
    vi.spyOn(performance, 'now').mockImplementation(() => now)
    vi.stubGlobal('requestAnimationFrame', (cb: FrameRequestCallback) => {
      setTimeout(() => {
        now += 100
        cb(now)
      }, 100)
      return 1
    })
  })
  afterEach(() => {
    vi.useRealTimers()
    vi.unstubAllGlobals()
    vi.restoreAllMocks()
  })

  test('holds the start value during the delay, then reaches the target', async () => {
    let api!: ReturnType<typeof useCountUp>
    const Comp = defineComponent({
      setup() {
        api = useCountUp(385, 1000, 0, { from: 561, delayMs: 500 })
        return () => h('span', api.text.value)
      },
    })
    mount(Comp)
    expect(api.text.value).toBe('561')
    vi.advanceTimersByTime(400)
    expect(api.text.value).toBe('561')
    vi.advanceTimersByTime(2000)
    expect(api.text.value).toBe('385')
  })
})
