import * as THREE from 'three'
import { disposeGroup, lines, rand, solid, type SceneFactory } from './helpers'

/** A breathing network with a red core: does the market tip or fragment? */
export const s14Network: SceneFactory = ({ scene, camera, palette }) => {
  const group = new THREE.Group()
  const n = 48
  const base: THREE.Vector3[] = []
  for (let i = 0; i < n; i++) {
    const u = rand(i) * Math.PI * 2
    const v = Math.acos(2 * rand(i + 99) - 1)
    base.push(new THREE.Vector3(Math.sin(v) * Math.cos(u), Math.sin(v) * Math.sin(u), Math.cos(v)).multiplyScalar(2.2))
  }
  const pairs: [number, number][] = []
  for (let i = 0; i < n; i++)
    for (let j = i + 1; j < n; j++) if (base[i].distanceTo(base[j]) < 1.25) pairs.push([i, j])
  const linePos = new Float32Array(pairs.length * 6)
  const lineGeo = new THREE.BufferGeometry()
  lineGeo.setAttribute('position', new THREE.BufferAttribute(linePos, 3))
  group.add(new THREE.LineSegments(lineGeo, lines(palette.muted, 0.45)))
  const ptPos = new Float32Array(n * 3)
  const ptGeo = new THREE.BufferGeometry()
  ptGeo.setAttribute('position', new THREE.BufferAttribute(ptPos, 3))
  group.add(new THREE.Points(ptGeo, new THREE.PointsMaterial({ color: palette.key, size: 0.1 })))
  const core = new THREE.Mesh(new THREE.SphereGeometry(0.45, 24, 16), solid(palette.overprint))
  group.add(core)
  scene.add(group)
  camera.position.set(0, 0, 8.5)
  camera.lookAt(0, 0, 0)

  const v = new THREE.Vector3()
  return {
    update(t) {
      group.rotation.y = t * 0.15
      group.rotation.x = Math.sin(t * 0.1) * 0.3
      const breath = 1 + 0.12 * Math.sin(t * 0.9)
      for (let i = 0; i < n; i++) {
        v.copy(base[i]).multiplyScalar(breath + 0.05 * Math.sin(t * 2 + i))
        v.toArray(ptPos, i * 3)
      }
      pairs.forEach(([a, b], k) => {
        linePos[k * 6] = ptPos[a * 3]
        linePos[k * 6 + 1] = ptPos[a * 3 + 1]
        linePos[k * 6 + 2] = ptPos[a * 3 + 2]
        linePos[k * 6 + 3] = ptPos[b * 3]
        linePos[k * 6 + 4] = ptPos[b * 3 + 1]
        linePos[k * 6 + 5] = ptPos[b * 3 + 2]
      })
      ptGeo.attributes.position.needsUpdate = true
      lineGeo.attributes.position.needsUpdate = true
      core.scale.setScalar(2 - breath)
    },
    dispose: () => disposeGroup(scene, group),
  }
}
