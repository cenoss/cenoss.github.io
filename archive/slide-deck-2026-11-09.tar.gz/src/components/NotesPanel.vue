<script setup lang="ts">
import { computed } from 'vue'
import { useI18n } from '../composables/i18n'

const props = defineProps<{ notesKey: string; budgetSec: number }>()
const { t } = useI18n()

const budget = computed(() => {
  const m = Math.floor(props.budgetSec / 60)
  const s = props.budgetSec % 60
  return `${m}:${String(s).padStart(2, '0')}`
})
</script>

<template>
  <aside class="notes" aria-live="polite">
    <p class="notes-meta">
      <span>{{ t('chrome.notes') }}</span>
      <span class="notes-budget">{{ t('chrome.budget') }} {{ budget }}</span>
    </p>
    <p class="notes-text">{{ t(notesKey) }}</p>
  </aside>
</template>

<style scoped>
.notes {
  position: absolute;
  left: var(--pad-x);
  right: var(--pad-x);
  bottom: 3.2cqw;
  z-index: 10;
  background: var(--key);
  color: var(--stock);
  border-left: 0.5cqw solid var(--tbd);
  padding: 1.1cqw 1.5cqw;
  display: grid;
  row-gap: 0.5cqw;
  font-size: var(--t-body);
}
.notes-meta {
  display: flex;
  justify-content: space-between;
  font-size: var(--t-foot);
  color: rgba(228, 230, 226, 0.7);
}
.notes-budget {
  font-variant-numeric: tabular-nums;
}
.notes-text {
  line-height: 1.45;
}
</style>
