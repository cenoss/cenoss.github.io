import * as THREE from 'three'
import { disposeGroup, lines, solid, type SceneFactory } from './helpers'

/** Six question nodes around the focal firm, each lighting in turn. */
export const s5Questions: SceneFactory = ({ scene, camera, palette }) => {
  const group = new THREE.Group()
  const center = new THREE.Mesh(new THREE.SphereGeometry(0.35, 20, 14), solid(palette.overprint))
  group.add(center)
  const nodes: THREE.Mesh[] = []
  const r = 2.6
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2
    const node = new THREE.Mesh(new THREE.SphereGeometry(0.18, 14, 10), solid(palette.muted))
    node.position.set(Math.cos(a) * r, Math.sin(a) * r, 0)
    group.add(node)
    nodes.push(node)
    const link = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), node.position.clone()]), lines(palette.muted, 0.35))
    group.add(link)
  }
  group.rotation.x = 0.5
  scene.add(group)
  camera.position.set(0, 0, 8.5)
  camera.lookAt(0, 0, 0)

  return {
    update(t) {
      group.rotation.z = t * 0.12
      const active = Math.floor(t * 0.9) % 6
      nodes.forEach((n, i) => {
        const pulse = i === active ? 1 + 0.6 * Math.abs(Math.sin(t * 2.8)) : 1
        n.scale.setScalar(pulse)
        ;(n.material as THREE.MeshBasicMaterial).color.setHex(i === active ? palette.key : palette.muted)
      })
      center.scale.setScalar(1 + 0.08 * Math.sin(t * 1.5))
    },
    dispose: () => disposeGroup(scene, group),
  }
}
