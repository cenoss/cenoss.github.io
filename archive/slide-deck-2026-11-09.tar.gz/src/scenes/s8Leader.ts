import * as THREE from 'three'
import { disposeGroup, rand, solid, wire, type SceneFactory } from './helpers'

/** The market leader at the centre, rivals orbiting at their own speeds. */
export const s8Leader: SceneFactory = ({ scene, camera, palette }) => {
  const group = new THREE.Group()
  const leader = new THREE.Mesh(new THREE.SphereGeometry(0.6, 24, 16), solid(palette.producer))
  const halo = new THREE.Mesh(new THREE.SphereGeometry(0.9, 16, 12), wire(palette.producer, 0.25))
  group.add(leader, halo)
  const rivals = Array.from({ length: 6 }, (_, i) => {
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.14 + rand(i) * 0.1, 12, 10), solid(palette.muted))
    group.add(m)
    return { m, r: 1.5 + i * 0.32, speed: 0.9 - i * 0.1, tilt: rand(i + 10) * 0.6, phase: rand(i + 20) * Math.PI * 2 }
  })
  scene.add(group)
  camera.position.set(0, 1, 5)
  camera.lookAt(0, 0, 0)

  return {
    update(t) {
      leader.scale.setScalar(1 + 0.05 * Math.sin(t * 2))
      halo.scale.setScalar(1 + 0.12 * Math.sin(t * 1.2))
      halo.rotation.y = t * 0.3
      rivals.forEach(({ m, r, speed, tilt, phase }) => {
        const a = t * speed + phase
        m.position.set(Math.cos(a) * r, Math.sin(a) * r * tilt, Math.sin(a) * r * 0.4)
      })
    },
    dispose: () => disposeGroup(scene, group),
  }
}
