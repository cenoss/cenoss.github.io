import { describe, expect, test } from 'vitest'
import { useLang } from '../src/composables/useLang'

const messages = {
  en: { hello: 'Hello', only_en: 'x' },
  'zh-TW': { hello: '你好', only_en: 'y' },
}

function fakeStorage(initial: Record<string, string> = {}) {
  const store = { ...initial }
  return {
    getItem: (k: string) => (k in store ? store[k] : null),
    setItem: (k: string, v: string) => {
      store[k] = v
    },
    store,
  }
}

describe('useLang', () => {
  test('defaults to English', () => {
    const { lang, t } = useLang(messages, null)
    expect(lang.value).toBe('en')
    expect(t('hello')).toBe('Hello')
  })

  test('toggle switches to zh-TW and back', () => {
    const { lang, t, toggle } = useLang(messages, null)
    toggle()
    expect(lang.value).toBe('zh-TW')
    expect(t('hello')).toBe('你好')
    toggle()
    expect(lang.value).toBe('en')
  })

  test('returns the key itself when a string is missing', () => {
    const { t } = useLang(messages, null)
    expect(t('does.not.exist')).toBe('does.not.exist')
  })

  test('restores a saved language from storage', () => {
    const storage = fakeStorage({ lang: 'zh-TW' })
    const { lang } = useLang(messages, storage)
    expect(lang.value).toBe('zh-TW')
  })

  test('ignores an invalid saved language', () => {
    const storage = fakeStorage({ lang: 'fr' })
    const { lang } = useLang(messages, storage)
    expect(lang.value).toBe('en')
  })

  test('saves the language on toggle', () => {
    const storage = fakeStorage()
    const { toggle } = useLang(messages, storage)
    toggle()
    expect(storage.store.lang).toBe('zh-TW')
  })

  test('survives a storage that throws', () => {
    const broken = {
      getItem: () => {
        throw new Error('blocked')
      },
      setItem: () => {
        throw new Error('blocked')
      },
    }
    const { lang, toggle } = useLang(messages, broken)
    expect(lang.value).toBe('en')
    toggle()
    expect(lang.value).toBe('zh-TW')
  })
})
