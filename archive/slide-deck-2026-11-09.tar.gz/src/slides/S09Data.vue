<script setup lang="ts">
import SlideShell from '../components/SlideShell.vue'
import TbdBadge from '../components/TbdBadge.vue'
import ThreeScene from '../components/ThreeScene.vue'
import { scenes } from '../scenes'
import { useI18n } from '../composables/i18n'
const { t } = useI18n()
const groups = ['g1', 'g2', 'g3', 'g4']
</script>

<template>
  <SlideShell kicker="s9.kicker" title="s9.title">
    <div class="data">
      <p class="mode">{{ t('s9.mode') }}</p>
      <ul v-stagger class="groups">
        <li v-for="g in groups" :key="g">
          <h3>{{ t(`s9.${g}_h`) }}</h3>
          <p>{{ t(`s9.${g}`) }}</p>
        </li>
      </ul>
    </div>
    <ThreeScene :scene="scenes.s9" :opacity="0.8" :style="{ right: 0, bottom: 0, width: '40cqw', height: '16cqw' }" />
    <template #foot>
      <span>{{ t('s9.indicative') }}</span>
      <span>{{ t('s9.tbd_note') }}</span>
      <TbdBadge />
    </template>
  </SlideShell>
</template>

<style scoped>
.data {
  height: 100%;
  display: grid;
  grid-template-rows: auto 1fr;
  row-gap: 1.4cqw;
  align-content: start;
}
.mode {
  animation: rise 560ms var(--ease-out) var(--stagger-base) both;
  color: var(--muted);
  max-width: 70ch;
}
.groups {
  --stagger-base: 540ms;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.4cqw 2.4cqw;
  align-content: start;
}
.groups li {
  display: grid;
  row-gap: 0.4cqw;
  padding-top: 0.7cqw;
  border-top: 1px solid var(--line);
}
h3 {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: var(--t-h3);
}
p {
  font-size: 1.45cqw;
  line-height: 1.4;
  color: var(--key);
}
</style>
