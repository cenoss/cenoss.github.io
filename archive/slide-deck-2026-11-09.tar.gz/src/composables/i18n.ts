import { inject, provide, type InjectionKey } from 'vue'
import { useLang, type Messages } from './useLang'

type I18n = ReturnType<typeof useLang>
type StorageLike = Parameters<typeof useLang>[1]

const KEY: InjectionKey<I18n> = Symbol('i18n')

export function provideI18n(messages: Messages, storage: StorageLike) {
  const api = useLang(messages, storage)
  provide(KEY, api)
  return api
}

export function useI18n(): I18n {
  const api = inject(KEY)
  if (!api) throw new Error('useI18n called outside an i18n provider')
  return api
}
