import * as THREE from 'three'
import { disposeGroup, lines, solid, type SceneFactory } from './helpers'

/** Nine framework blocks stacked as a column with a pulse travelling through them. */
export const s7Framework: SceneFactory = ({ scene, camera, palette }) => {
  const group = new THREE.Group()
  const n = 9
  const blocks: THREE.Mesh[] = []
  const pts: THREE.Vector3[] = []
  for (let i = 0; i < n; i++) {
    const block = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.42, 0.5), solid(palette.muted, 0.55))
    block.position.set(Math.sin(i * 0.8) * 0.5, (n - 1) / 2 * 0.62 - i * 0.62, 0)
    group.add(block)
    blocks.push(block)
    pts.push(block.position.clone())
  }
  group.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), lines(palette.muted, 0.4)))
  const pulse = new THREE.Mesh(new THREE.SphereGeometry(0.14, 12, 12), solid(palette.key))
  group.add(pulse)
  const curve = new THREE.CatmullRomCurve3(pts)
  scene.add(group)
  camera.position.set(0, 0, 8)
  camera.lookAt(0, 0, 0)

  return {
    update(t) {
      group.rotation.y = Math.sin(t * 0.35) * 0.5
      const p = (t * 0.18) % 1
      curve.getPointAt(p, pulse.position)
      blocks.forEach((b, i) => {
        const d = Math.abs(i / (n - 1) - p)
        const lit = Math.max(0, 1 - d * 6)
        const mat = b.material as THREE.MeshBasicMaterial
        mat.color.setHex(lit > 0.1 ? palette.key : palette.muted)
        mat.opacity = 0.45 + 0.55 * lit
        b.scale.setScalar(1 + 0.12 * lit)
      })
    },
    dispose: () => disposeGroup(scene, group),
  }
}
