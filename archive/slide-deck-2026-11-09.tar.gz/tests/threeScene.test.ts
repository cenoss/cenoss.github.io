import { describe, expect, test } from 'vitest'
import { mount } from '@vue/test-utils'
import ThreeScene from '../src/components/ThreeScene.vue'
import { scenes } from '../src/scenes'

describe('ThreeScene', () => {
  test('mounts and unmounts without WebGL support', () => {
    const wrapper = mount(ThreeScene, { props: { scene: scenes.s2 } })
    expect(wrapper.find('.scene').exists()).toBe(true)
    expect(() => wrapper.unmount()).not.toThrow()
  })
})
