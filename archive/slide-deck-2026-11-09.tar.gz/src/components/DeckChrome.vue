<script setup lang="ts">
import { useI18n } from '../composables/i18n'

defineProps<{ index: number; total: number }>()
const emit = defineEmits<{ toggleLang: [] }>()
const { t } = useI18n()
</script>

<template>
  <div class="folio-end">
    <p class="counter"><span>{{ index + 1 }}</span> / {{ total }}</p>
    <button type="button" class="lang" @click="emit('toggleLang')">{{ t('chrome.switch_to') }}</button>
  </div>
  <!-- progress as a press sheet's colour bar: one patch per slide -->
  <ol class="strip" aria-hidden="true">
    <li v-for="n in total" :key="n" :class="{ done: n - 1 < index, now: n - 1 === index }" />
  </ol>
  <p class="hint">{{ t('chrome.hint') }}</p>
</template>

<style scoped>
.folio-end {
  position: absolute;
  top: var(--pad-top);
  right: var(--pad-x);
  display: flex;
  align-items: center;
  gap: 1.4cqw;
  z-index: 5;
  transform: translateY(-0.15cqw);
}
.counter {
  font-size: var(--t-kicker);
  color: var(--muted);
  font-variant-numeric: tabular-nums;
}
.counter span {
  color: var(--key);
  font-weight: 600;
}
.lang {
  font-size: var(--t-kicker);
  line-height: 1;
  padding: 0.3em 0.7em;
  background: var(--key);
  color: var(--stock);
}
.lang:hover {
  background: var(--overprint);
}
.strip {
  position: absolute;
  left: var(--pad-x);
  bottom: 1.25cqw;
  display: flex;
  gap: 0.18cqw;
}
.strip li {
  width: 1.3cqw;
  height: 0.7cqw;
  box-shadow: inset 0 0 0 1px var(--line);
  transition: background-color 240ms ease;
}
.strip li.done {
  background: var(--tint-2);
  box-shadow: none;
}
.strip li.now {
  background: var(--key);
  box-shadow: none;
}
.hint {
  position: absolute;
  right: var(--pad-x);
  bottom: 1.15cqw;
  font-size: 0.85cqw;
  color: var(--muted);
}
@media (prefers-reduced-motion: reduce) {
  .strip li {
    transition: none;
  }
}
</style>
