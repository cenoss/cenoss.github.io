import * as THREE from 'three'
import { disposeGroup, easeInOut, rand, solid, wire, type SceneFactory } from './helpers'

/** Scattered text fragments pass through the agent and come out as a tidy table. */
export const s11Agent: SceneFactory = ({ scene, camera, palette }) => {
  const group = new THREE.Group()
  const agent = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.6, 1.2), wire(palette.key, 0.6))
  group.add(agent)
  const cols = 6
  const rows = 5
  const count = cols * rows
  const items = Array.from({ length: count }, (_, i) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.16, 0.16), solid(palette.key))
    group.add(m)
    const c = i % cols
    const r = Math.floor(i / cols)
    return {
      m,
      start: new THREE.Vector3(-4.4 + rand(i) * 1.6, (rand(i + 100) - 0.5) * 2.4, (rand(i + 200) - 0.5) * 1.6),
      end: new THREE.Vector3(2.4 + c * 0.34, (rows - 1) / 2 * 0.34 - r * 0.34, 0),
      phase: rand(i + 300),
      jitter: rand(i + 400) * Math.PI * 2,
    }
  })
  scene.add(group)
  camera.position.set(0, 0.5, 5.2)
  camera.lookAt(0, 0, 0)

  const mutedC = new THREE.Color(palette.muted)
  const paperC = new THREE.Color(palette.key)
  return {
    update(t) {
      agent.rotation.y = t * 0.6
      items.forEach(({ m, start, end, phase, jitter }) => {
        const p = (t * 0.14 + phase) % 1
        const e = easeInOut(p)
        m.position.lerpVectors(start, end, e)
        const chaos = 1 - e
        m.position.y += Math.sin(t * 3 + jitter) * 0.25 * chaos
        m.rotation.set(t * chaos, jitter * chaos, 0)
        ;(m.material as THREE.MeshBasicMaterial).color.lerpColors(mutedC, paperC, e)
      })
    },
    dispose: () => disposeGroup(scene, group),
  }
}
