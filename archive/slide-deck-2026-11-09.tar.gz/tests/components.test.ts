import { describe, expect, test } from 'vitest'
import { defineComponent, h } from 'vue'
import { mount } from '@vue/test-utils'
import { provideI18n } from '../src/composables/i18n'
import SlideShell from '../src/components/SlideShell.vue'
import TbdBadge from '../src/components/TbdBadge.vue'
import DiagramEmbed from '../src/components/DiagramEmbed.vue'

const messages = {
  en: { 'chrome.tbd': 'TBD', 'chrome.zoom': 'Click to zoom', 'chrome.close': 'Close', 'x.title': 'Hello', 'x.kicker': 'Kick' },
  'zh-TW': { 'chrome.tbd': '待驗證', 'chrome.zoom': '點擊放大', 'chrome.close': '關閉', 'x.title': '你好', 'x.kicker': '開場' },
}

/** Mounts `child` under a parent that provides i18n, returns wrapper + lang controls. */
function mountWithI18n(child: ReturnType<typeof defineComponent>, props: Record<string, unknown> = {}, slots: Record<string, string> = {}) {
  let api!: ReturnType<typeof provideI18n>
  const Host = defineComponent({
    setup() {
      api = provideI18n(messages, null)
      return () => h(child, props, Object.fromEntries(Object.entries(slots).map(([k, v]) => [k, () => v])))
    },
  })
  const wrapper = mount(Host)
  return { wrapper, api }
}

describe('SlideShell', () => {
  test('renders translated kicker and title from keys', () => {
    const { wrapper } = mountWithI18n(SlideShell, { kicker: 'x.kicker', title: 'x.title' }, { default: 'body' })
    expect(wrapper.text()).toContain('Kick')
    expect(wrapper.text()).toContain('Hello')
    expect(wrapper.text()).toContain('body')
  })

  test('re-renders when the language toggles', async () => {
    const { wrapper, api } = mountWithI18n(SlideShell, { kicker: 'x.kicker', title: 'x.title' })
    api.toggle()
    await wrapper.vm.$nextTick()
    expect(wrapper.text()).toContain('你好')
  })
})

describe('TbdBadge', () => {
  test('shows the localized TBD label', () => {
    const { wrapper } = mountWithI18n(TbdBadge)
    expect(wrapper.text()).toBe('TBD')
  })
})

describe('DiagramEmbed', () => {
  test('shows no overlay until clicked', () => {
    const { wrapper } = mountWithI18n(DiagramEmbed, { src: '/diagrams/A-framework.svg', alt: 'A' })
    expect(wrapper.find('[data-test="overlay"]').exists()).toBe(false)
  })

  test('opens the overlay on click and closes on Escape', async () => {
    const { wrapper } = mountWithI18n(DiagramEmbed, { src: '/diagrams/A-framework.svg', alt: 'A' })
    await wrapper.find('button').trigger('click')
    expect(wrapper.find('[data-test="overlay"]').exists()).toBe(true)
    window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }))
    await wrapper.vm.$nextTick()
    expect(wrapper.find('[data-test="overlay"]').exists()).toBe(false)
  })
})
