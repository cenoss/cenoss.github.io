import * as THREE from 'three'
import { disposeGroup, lines, rand, solid, type SceneFactory } from './helpers'

/** Particles run through seven pipeline nodes; some loop back from verification. */
export const s10Pipeline: SceneFactory = ({ scene, camera, palette }) => {
  const group = new THREE.Group()
  const n = 7
  const nodes = Array.from({ length: n }, (_, i) => new THREE.Vector3((i - (n - 1) / 2) * 1.25, 0, 0))
  nodes.forEach((p, i) => {
    const m = new THREE.Mesh(new THREE.SphereGeometry(i === 3 ? 0.2 : 0.13, 14, 10), solid(i === 3 ? palette.key : palette.muted))
    m.position.copy(p)
    group.add(m)
  })
  const main = new THREE.CatmullRomCurve3(nodes)
  const back = new THREE.CatmullRomCurve3([nodes[3], new THREE.Vector3(nodes[2].x, -1.1, 0.2), new THREE.Vector3(nodes[1].x, -1.1, 0.2), nodes[0]])
  group.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(main.getPoints(40)), lines(palette.muted, 0.6)))
  group.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(back.getPoints(40)), lines(palette.key, 0.4)))

  const count = 90
  const pos = new Float32Array(count * 3)
  const col = new Float32Array(count * 3)
  const seeds = Array.from({ length: count }, (_, i) => ({ phase: rand(i), loop: rand(i + 500) < 0.3 }))
  const geo = new THREE.BufferGeometry()
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3))
  geo.setAttribute('color', new THREE.BufferAttribute(col, 3))
  group.add(new THREE.Points(geo, new THREE.PointsMaterial({ size: 0.1, vertexColors: true })))
  scene.add(group)
  camera.position.set(0, 1.2, 4.8)
  camera.lookAt(0, -0.45, 0)

  const paper = new THREE.Color(palette.key)
  const amber = new THREE.Color(palette.key)
  const v = new THREE.Vector3()
  return {
    update(t) {
      for (let i = 0; i < count; i++) {
        const s = seeds[i]
        const p = (t * 0.16 + s.phase) % 1
        if (s.loop) {
          // forward to the verification node, then back along the amber loop
          if (p < 0.5) main.getPointAt(p * 1.0, v)
          else back.getPointAt((p - 0.5) * 2, v)
          amber.toArray(col, i * 3)
        } else {
          main.getPointAt(p, v)
          paper.toArray(col, i * 3)
        }
        v.toArray(pos, i * 3)
      }
      geo.attributes.position.needsUpdate = true
      geo.attributes.color.needsUpdate = true
    },
    dispose: () => disposeGroup(scene, group),
  }
}
