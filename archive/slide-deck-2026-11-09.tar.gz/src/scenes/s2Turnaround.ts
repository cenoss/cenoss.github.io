import * as THREE from 'three'
import { disposeGroup, solid, type SceneFactory } from './helpers'

/** Six yearly bars: four below the line in red, then the climb above it in teal. */
export const s2Turnaround: SceneFactory = ({ scene, camera, palette }) => {
  const group = new THREE.Group()
  const n = 6
  const bars: THREE.Mesh[] = []
  for (let i = 0; i < n; i++) {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(0.8, 1, 0.8), solid(palette.muted))
    mesh.position.x = (i - (n - 1) / 2) * 1.5
    group.add(mesh)
    bars.push(mesh)
  }
  const baseline = new THREE.Mesh(new THREE.BoxGeometry(n * 1.5 + 0.6, 0.03, 1.2), solid(palette.muted, 0.7))
  group.add(baseline)
  group.rotation.x = 0.35
  scene.add(group)
  camera.position.set(0, 0.8, 5.6)
  camera.lookAt(0, 0, 0)

  const target = [-0.9, -1.3, -1.1, -1.5, 0.9, 1.6]
  return {
    update(t) {
      const cycle = (t % 6) / 6
      group.rotation.y = Math.sin(t * 0.3) * 0.35
      bars.forEach((bar, i) => {
        const reveal = THREE.MathUtils.clamp((cycle - i / n) * n * 1.4, 0, 1)
        const h = target[i] * reveal * (0.9 + 0.1 * Math.sin(t * 2 + i))
        bar.scale.y = Math.max(Math.abs(h), 0.02)
        bar.position.y = h / 2
        const mat = bar.material as THREE.MeshBasicMaterial
        mat.color.setHex(h < 0 ? palette.producer : palette.gateway)
        mat.opacity = 0.35 + 0.65 * reveal
        mat.transparent = true
      })
    },
    dispose: () => disposeGroup(scene, group),
  }
}
