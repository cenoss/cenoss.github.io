import { ref } from 'vue'

export type DeckAction =
  | 'next'
  | 'prev'
  | 'first'
  | 'last'
  | 'lang'
  | 'notes'
  | 'fullscreen'
  | 'escape'

const KEY_MAP: Record<string, DeckAction> = {
  ArrowRight: 'next',
  ' ': 'next',
  PageDown: 'next',
  ArrowLeft: 'prev',
  PageUp: 'prev',
  Home: 'first',
  End: 'last',
  l: 'lang',
  n: 'notes',
  f: 'fullscreen',
  Escape: 'escape',
}

export function keyToAction(key: string): DeckAction | null {
  return KEY_MAP[key] ?? KEY_MAP[key.toLowerCase()] ?? null
}

function readHash(total: number): number {
  const m = /^#\/(\d+)$/.exec(window.location.hash)
  if (!m) return 0
  const n = Number(m[1]) - 1
  return Math.min(Math.max(n, 0), total - 1)
}

export function useDeck(total: number) {
  const index = ref(readHash(total))
  const direction = ref<'next' | 'prev'>('next')

  const clamp = (n: number) => Math.min(Math.max(n, 0), total - 1)
  const goTo = (n: number) => {
    const target = clamp(n)
    if (target !== index.value) direction.value = target > index.value ? 'next' : 'prev'
    index.value = target
    window.location.hash = `#/${index.value + 1}`
  }

  const syncFromHash = () => goTo(readHash(total))

  return {
    index,
    direction,
    total,
    goTo,
    syncFromHash,
    next: () => goTo(index.value + 1),
    prev: () => goTo(index.value - 1),
    first: () => goTo(0),
    last: () => goTo(total - 1),
  }
}
