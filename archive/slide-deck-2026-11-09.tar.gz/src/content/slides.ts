import type { Component } from 'vue'
import S01Title from '../slides/S01Title.vue'
import S02Puzzle from '../slides/S02Puzzle.vue'
import S03Layers from '../slides/S03Layers.vue'
import S04Question from '../slides/S04Question.vue'
import S05Questions from '../slides/S05Questions.vue'
import S06Lenses from '../slides/S06Lenses.vue'
import S07Framework from '../slides/S07Framework.vue'
import S08Why from '../slides/S08Why.vue'
import S09Data from '../slides/S09Data.vue'
import S10Pipeline from '../slides/S10Pipeline.vue'
import S11Agent from '../slides/S11Agent.vue'
import S12Output from '../slides/S12Output.vue'
import S13Team from '../slides/S13Team.vue'
import S14Close from '../slides/S14Close.vue'

export interface SlideDef {
  id: string
  component: Component
  notesKey: string
  budgetSec: number
}

const order: [Component, number][] = [
  [S01Title, 20],
  [S02Puzzle, 50],
  [S03Layers, 45],
  [S04Question, 40],
  [S05Questions, 60],
  [S06Lenses, 40],
  [S07Framework, 45],
  [S08Why, 45],
  [S09Data, 50],
  [S10Pipeline, 50],
  [S11Agent, 35],
  [S12Output, 50],
  [S13Team, 40],
  [S14Close, 10],
]

export const slides: SlideDef[] = order.map(([component, budgetSec], i) => ({
  id: `s${i + 1}`,
  component,
  notesKey: `notes.s${i + 1}`,
  budgetSec,
}))
