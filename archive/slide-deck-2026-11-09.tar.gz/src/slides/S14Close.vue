<script setup lang="ts">
import ThreeScene from '../components/ThreeScene.vue'
import { scenes } from '../scenes'
import { useI18n } from '../composables/i18n'
const { t } = useI18n()
</script>

<template>
  <section class="slide close">
    <p class="kicker">{{ t('s14.kicker') }}</p>
    <div v-stagger class="close-main">
      <span class="mark" aria-hidden="true" />
      <h2 class="close-title">{{ t('s14.title') }}</h2>
      <p class="close-sub">{{ t('s14.sub') }}</p>
    </div>
    <p class="disclosure">{{ t('s14.disclosure') }}</p>
    <ThreeScene :scene="scenes.s14" :style="{ right: '2cqw', top: '6cqw', bottom: '8cqw', width: '36cqw' }" />
  </section>
</template>

<style scoped>
.close {
  grid-template-rows: auto 1fr auto;
  z-index: 0;
}
.close-main {
  align-self: center;
  display: grid;
  row-gap: 1.4cqw;
}
.mark {
  /* the title slide's two plates and their overprint, as one registered bar */
  width: 9cqw;
  height: 0.7cqw;
  background: linear-gradient(
    90deg,
    var(--producer) 0 33.4%,
    var(--overprint) 33.4% 66.6%,
    var(--gateway) 66.6%
  );
  transform-origin: left;
  animation: draw 700ms var(--ease-out) both;
}
.close-main {
  --stagger-base: 200ms;
  --stagger-step: 160ms;
}
.close-title {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: 5cqw;
  line-height: 1.05;
  max-width: 20ch;
  text-wrap: balance;
}
:lang(zh-TW) .close-title {
  font-size: 4cqw;
  line-height: 1.2;
  max-width: 14em;
}
.close-sub {
  font-size: var(--t-lead);
  color: var(--muted);
}
.disclosure {
  animation: rise 500ms var(--ease-out) 900ms both;
  font-size: var(--t-foot);
  color: var(--muted);
  max-width: 90ch;
  line-height: 1.4;
  padding-right: 8cqw;
}
</style>
