import { describe, expect, test } from 'vitest'
import en from '../src/content/en.json'
import zh from '../src/content/zh-TW.json'

describe('content files', () => {
  test('en and zh-TW have identical key sets', () => {
    const enKeys = Object.keys(en).sort()
    const zhKeys = Object.keys(zh).sort()
    expect(zhKeys).toEqual(enKeys)
  })

  test('no string is empty', () => {
    for (const [k, v] of Object.entries({ ...en, ...zh })) {
      expect(typeof v, k).toBe('string')
      expect((v as string).trim().length, k).toBeGreaterThan(0)
    }
  })
})
