<script setup lang="ts">
import SlideShell from '../components/SlideShell.vue'
import DiagramEmbed from '../components/DiagramEmbed.vue'
import ThreeScene from '../components/ThreeScene.vue'
import { scenes } from '../scenes'
import { useI18n } from '../composables/i18n'
const { t } = useI18n()
</script>

<template>
  <SlideShell kicker="s7.kicker" title="s7.title" foot="s7.flow">
    <div class="framework">
      <DiagramEmbed src="/diagrams/A-framework.svg" alt="Diagram A: analysis framework">
        {{ t('s7.caption') }}
      </DiagramEmbed>
    </div>
    <ThreeScene :scene="scenes.s7" :style="{ right: 0, top: 0, bottom: 0, width: '24cqw' }" />
  </SlideShell>
</template>

<style scoped>
.framework {
  height: 100%;
  width: calc(100% - 26cqw);
  min-height: 0;
}
</style>
