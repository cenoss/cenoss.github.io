<script setup lang="ts">
import SlideShell from '../components/SlideShell.vue'
import ThreeScene from '../components/ThreeScene.vue'
import { scenes } from '../scenes'
import { PALETTE } from '../scenes/helpers'
import { useI18n } from '../composables/i18n'
import { useCountUp } from '../composables/useCountUp'
const { t } = useI18n()
const gateways = [
  { key: 's3.gw1', pct: 49 },
  { key: 's3.gw2', pct: 48 },
  { key: 's3.gw3', pct: 47 },
].map((g) => ({ ...g, count: useCountUp(g.pct, 1100, 0, { delayMs: 450 }) }))
</script>

<template>
  <SlideShell kicker="s3.kicker" title="s3.title" foot="s3.ad">
    <div class="layers">
      <div v-stagger class="bands">
        <div class="band band-producer">
          <h3>{{ t('s3.layer1') }}</h3>
          <p class="band-list">{{ t('s3.layer1_list') }}</p>
        </div>
        <div class="band band-gateway">
          <h3>{{ t('s3.layer2') }}</h3>
          <ul class="gateways">
            <li v-for="g in gateways" :key="g.key">
              <span class="gw-pct">{{ g.count.text.value }}%</span>
              <span class="gw-name">{{ t(g.key) }}</span>
            </li>
          </ul>
          <p class="gw-note">{{ t('s3.gateway_note') }}</p>
        </div>
      </div>
      <aside class="both">
        <p class="both-name">ETtoday</p>
        <p class="both-text">{{ t('s3.role') }}</p>
        <ThreeScene :scene="scenes.s3" :opacity="0.6" :palette="{ key: PALETTE.stock }" :style="{ inset: 0 }" />
      </aside>
    </div>
  </SlideShell>
</template>

<style scoped>
.layers {
  height: 100%;
  display: grid;
  grid-template-columns: 1fr 0.42fr;
  column-gap: 2.4cqw;
}
.bands {
  display: grid;
  grid-template-rows: 1fr 1.4fr;
  row-gap: 1.2cqw;
}
.band {
  padding: 1.2cqw 1.6cqw;
  border-left: 0.6cqw solid;
  display: grid;
  align-content: center;
  row-gap: 0.8cqw;
}
.band h3 {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: var(--t-h3);
}
.band-producer {
  border-color: var(--producer);
  background: var(--producer-soft);
}
.band-gateway {
  border-color: var(--gateway);
  background: var(--gateway-soft);
}
.band-list {
  color: var(--muted);
}
.gateways {
  display: grid;
  grid-template-columns: repeat(3, auto);
  justify-content: start;
  column-gap: 3cqw;
}
.gateways li {
  display: grid;
}
.gw-pct {
  font-family: var(--font-display);
  font-weight: 600;
  font-size: 4cqw;
  line-height: 1;
  color: var(--gateway-ink);
  font-variant-numeric: tabular-nums;
}
.gw-name {
  color: var(--key);
}
.gw-note {
  font-size: var(--t-foot);
  color: var(--muted);
}
.both {
  position: relative;
  z-index: 0;
  animation: rise 600ms var(--ease-out) 900ms both;
  background: var(--overprint);
  color: #fff;
  padding: 1.6cqw;
  display: grid;
  align-content: center;
  row-gap: 1cqw;
}
.both-name {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: 3.2cqw;
  line-height: 1;
}
.both-text {
  line-height: 1.4;
}
</style>
