<script setup lang="ts">
import { onBeforeUnmount, ref, watch } from 'vue'
import { useI18n } from '../composables/i18n'

defineProps<{ src: string; alt: string }>()

const { t } = useI18n()
const open = ref(false)

function onKey(e: KeyboardEvent) {
  if (e.key === 'Escape') open.value = false
}

watch(open, (isOpen) => {
  if (isOpen) window.addEventListener('keydown', onKey)
  else window.removeEventListener('keydown', onKey)
})
onBeforeUnmount(() => window.removeEventListener('keydown', onKey))
</script>

<template>
  <figure class="diagram">
    <button type="button" class="diagram-button" :aria-label="t('chrome.zoom')" @click="open = true">
      <img :src="src" :alt="alt" class="diagram-img" />
      <span class="diagram-zoom">{{ t('chrome.zoom') }}</span>
    </button>
    <figcaption v-if="$slots.default" class="diagram-caption"><slot /></figcaption>
  </figure>

  <div v-if="open" class="overlay" data-test="overlay" @click.self="open = false">
    <button type="button" class="overlay-close" @click="open = false">{{ t('chrome.close') }}</button>
    <div class="overlay-scroll">
      <img :src="src" :alt="alt" class="overlay-img" />
    </div>
  </div>
</template>

<style scoped>
.diagram {
  animation: pop 700ms var(--ease-out) 480ms both;
  margin: 0;
  display: grid;
  grid-template-rows: 1fr auto;
  min-height: 0;
  height: 100%;
  row-gap: 0.6cqw;
}
.diagram-button {
  position: relative;
  min-height: 0;
  background: #fff;
  display: grid;
  place-items: center;
  overflow: hidden;
  box-shadow: inset 0 0 0 1px var(--line);
}
.diagram-img {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: contain;
  display: block;
}
.diagram-zoom {
  position: absolute;
  right: 0.8cqw;
  bottom: 0.8cqw;
  font-size: var(--t-foot);
  color: var(--stock);
  background: var(--key);
  padding: 0.35em 0.7em;
}
.diagram-caption {
  font-size: var(--t-foot);
  color: var(--muted);
}

.overlay {
  position: fixed;
  inset: 0;
  z-index: 50;
  background: rgba(35, 31, 32, 0.94);
  display: grid;
  grid-template-rows: auto 1fr;
}
.overlay-close {
  justify-self: end;
  margin: 16px 20px 0;
  padding: 8px 14px;
  background: var(--stock);
  color: var(--key);
  font-size: 15px;
}
.overlay-scroll {
  overflow: auto;
  padding: 16px 20px 24px;
}
.overlay-img {
  display: block;
  width: 100%;
  background: #fff;
}
</style>
