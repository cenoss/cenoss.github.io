import { describe, expect, test, beforeEach } from 'vitest'
import { useDeck, keyToAction } from '../src/composables/useDeck'

beforeEach(() => {
  window.location.hash = ''
})

describe('useDeck navigation', () => {
  test('starts on the first slide', () => {
    const deck = useDeck(14)
    expect(deck.index.value).toBe(0)
  })

  test('next advances and stops at the last slide', () => {
    const deck = useDeck(3)
    deck.next()
    deck.next()
    deck.next()
    expect(deck.index.value).toBe(2)
  })

  test('prev retreats and stops at the first slide', () => {
    const deck = useDeck(3)
    deck.next()
    deck.prev()
    deck.prev()
    expect(deck.index.value).toBe(0)
  })

  test('goTo clamps out-of-range targets', () => {
    const deck = useDeck(5)
    deck.goTo(99)
    expect(deck.index.value).toBe(4)
    deck.goTo(-3)
    expect(deck.index.value).toBe(0)
  })

  test('first and last jump to the ends', () => {
    const deck = useDeck(5)
    deck.last()
    expect(deck.index.value).toBe(4)
    deck.first()
    expect(deck.index.value).toBe(0)
  })
})

describe('useDeck hash sync', () => {
  test('reads a 1-based slide number from the hash on creation', () => {
    window.location.hash = '#/7'
    const deck = useDeck(14)
    expect(deck.index.value).toBe(6)
  })

  test('ignores a hash that is not a slide number', () => {
    window.location.hash = '#/banana'
    const deck = useDeck(14)
    expect(deck.index.value).toBe(0)
  })

  test('writes the 1-based slide number to the hash when the slide changes', async () => {
    const deck = useDeck(14)
    deck.goTo(4)
    await Promise.resolve()
    expect(window.location.hash).toBe('#/5')
  })
})

describe('keyToAction', () => {
  test.each([
    ['ArrowRight', 'next'],
    [' ', 'next'],
    ['PageDown', 'next'],
    ['ArrowLeft', 'prev'],
    ['PageUp', 'prev'],
    ['Home', 'first'],
    ['End', 'last'],
    ['l', 'lang'],
    ['L', 'lang'],
    ['n', 'notes'],
    ['f', 'fullscreen'],
    ['Escape', 'escape'],
  ])('maps %s to %s', (key, action) => {
    expect(keyToAction(key)).toBe(action)
  })

  test('returns null for unbound keys', () => {
    expect(keyToAction('q')).toBeNull()
  })
})

describe('useDeck syncFromHash', () => {
  test('moves to the slide named in the current hash', () => {
    const deck = useDeck(14)
    window.location.hash = '#/9'
    deck.syncFromHash()
    expect(deck.index.value).toBe(8)
  })
})

describe('useDeck direction', () => {
  test('starts as next and flips to prev when going backwards', () => {
    const deck = useDeck(5)
    expect(deck.direction.value).toBe('next')
    deck.goTo(3)
    expect(deck.direction.value).toBe('next')
    deck.prev()
    expect(deck.direction.value).toBe('prev')
    deck.next()
    expect(deck.direction.value).toBe('next')
  })
})
