import type { SceneFactory } from './helpers'
import { s2Turnaround } from './s2Turnaround'
import { s3Layers } from './s3Layers'
import { s4Scope } from './s4Scope'
import { s5Questions } from './s5Questions'
import { s6Lenses } from './s6Lenses'
import { s7Framework } from './s7Framework'
import { s8Leader } from './s8Leader'
import { s9Data } from './s9Data'
import { s10Pipeline } from './s10Pipeline'
import { s11Agent } from './s11Agent'
import { s12Output } from './s12Output'
import { s13Team } from './s13Team'
import { s14Network } from './s14Network'

export const scenes: Record<string, SceneFactory> = {
  s2: s2Turnaround,
  s3: s3Layers,
  s4: s4Scope,
  s5: s5Questions,
  s6: s6Lenses,
  s7: s7Framework,
  s8: s8Leader,
  s9: s9Data,
  s10: s10Pipeline,
  s11: s11Agent,
  s12: s12Output,
  s13: s13Team,
  s14: s14Network,
}
