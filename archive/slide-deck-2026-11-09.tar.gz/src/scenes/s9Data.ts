import * as THREE from 'three'
import { disposeGroup, solid, type SceneFactory } from './helpers'

/** Four source layers of data points, scanned and verified one layer at a time. */
export const s9Data: SceneFactory = ({ scene, camera, palette }) => {
  const group = new THREE.Group()
  const layers = 4
  const cols = 14
  const rows = 6
  const count = layers * cols * rows
  const pos = new Float32Array(count * 3)
  const col = new Float32Array(count * 3)
  const muted = new THREE.Color(palette.muted)
  let k = 0
  for (let l = 0; l < layers; l++)
    for (let r = 0; r < rows; r++)
      for (let c = 0; c < cols; c++) {
        pos[k * 3] = (c - (cols - 1) / 2) * 0.32
        pos[k * 3 + 1] = (l - (layers - 1) / 2) * 0.8
        pos[k * 3 + 2] = (r - (rows - 1) / 2) * 0.32
        muted.toArray(col, k * 3)
        k++
      }
  const geo = new THREE.BufferGeometry()
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3))
  geo.setAttribute('color', new THREE.BufferAttribute(col, 3))
  const points = new THREE.Points(geo, new THREE.PointsMaterial({ size: 0.12, vertexColors: true }))
  group.add(points)
  const scanner = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.1, rows * 0.32 + 0.3), solid(palette.key))
  group.add(scanner)
  group.rotation.x = 0.45
  scene.add(group)
  camera.position.set(0, 0.8, 5.4)
  camera.lookAt(0, 0, 0)

  const teal = new THREE.Color(palette.key)
  const paper = new THREE.Color(palette.key)
  return {
    update(t) {
      group.rotation.y = -0.5 + Math.sin(t * 0.2) * 0.25
      const cycle = (t * 0.35) % layers
      const layer = Math.floor(cycle)
      const x = (cycle - layer) * (cols - 1) * 0.32 - ((cols - 1) / 2) * 0.32
      scanner.position.set(x, (layer - (layers - 1) / 2) * 0.8, 0)
      for (let i = 0; i < count; i++) {
        const l = Math.floor(i / (cols * rows))
        const px = pos[i * 3]
        const verified = l < layer || (l === layer && px <= x)
        const c = verified ? paper : muted
        const near = l === layer && Math.abs(px - x) < 0.2
        ;(near ? teal : c).toArray(col, i * 3)
      }
      geo.attributes.color.needsUpdate = true
    },
    dispose: () => disposeGroup(scene, group),
  }
}
