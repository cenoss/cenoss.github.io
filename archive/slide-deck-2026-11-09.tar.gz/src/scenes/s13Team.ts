import * as THREE from 'three'
import { disposeGroup, solid, wire, type SceneFactory } from './helpers'

/** Three pairs orbit the project; a marker sweeps a ring of seven weeks. */
export const s13Team: SceneFactory = ({ scene, camera, palette }) => {
  const group = new THREE.Group()
  const core = new THREE.Mesh(new THREE.IcosahedronGeometry(0.3, 0), wire(palette.key, 0.8))
  group.add(core)
  const pairs = [palette.key, palette.key, palette.key].map((c, i) => {
    const a = new THREE.Mesh(new THREE.SphereGeometry(0.17, 12, 10), solid(c))
    const b = a.clone()
    group.add(a, b)
    return { a, b, r: 1.2 + i * 0.5, speed: 0.8 - i * 0.15, tilt: 0.3 + i * 0.25 }
  })
  const ring = new THREE.Mesh(new THREE.TorusGeometry(2.9, 0.015, 8, 120), solid(palette.muted, 0.5))
  ring.rotation.x = Math.PI / 2.4
  group.add(ring)
  const ticks: THREE.Mesh[] = []
  for (let i = 0; i < 7; i++) {
    const tick = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8), solid(palette.muted))
    const a = (i / 7) * Math.PI * 2
    tick.position.set(Math.cos(a) * 2.9, Math.sin(a) * 2.9, 0)
    ring.add(tick)
    ticks.push(tick)
  }
  const marker = new THREE.Mesh(new THREE.SphereGeometry(0.12, 12, 12), solid(palette.key))
  ring.add(marker)
  scene.add(group)
  camera.position.set(0, 1.5, 11)
  camera.lookAt(0, 0, 0)

  return {
    update(t) {
      pairs.forEach(({ a, b, r, speed, tilt }) => {
        const ang = t * speed
        a.position.set(Math.cos(ang) * r, Math.sin(ang) * r * tilt, Math.sin(ang) * r * 0.5)
        b.position.set(-a.position.x, -a.position.y, -a.position.z)
      })
      core.rotation.set(t * 0.4, t * 0.3, 0)
      const a = t * 0.35
      marker.position.set(Math.cos(a) * 2.9, Math.sin(a) * 2.9, 0)
      const passed = Math.floor(((a % (Math.PI * 2)) / (Math.PI * 2)) * 7)
      ticks.forEach((tick, i) => (tick.material as THREE.MeshBasicMaterial).color.setHex(i <= passed ? palette.key : palette.muted))
    },
    dispose: () => disposeGroup(scene, group),
  }
}
