import { describe, expect, test } from 'vitest'
import { slides } from '../src/content/slides'
import en from '../src/content/en.json'

describe('slide list', () => {
  test('has fourteen slides in order', () => {
    expect(slides).toHaveLength(14)
    slides.forEach((s, i) => expect(s.id).toBe(`s${i + 1}`))
  })

  test('every slide has a notes key present in the content', () => {
    for (const s of slides) {
      expect(en, s.notesKey).toHaveProperty(s.notesKey)
    }
  })

  test('time budgets sum to about ten minutes', () => {
    const total = slides.reduce((sum, s) => sum + s.budgetSec, 0)
    expect(total).toBeGreaterThanOrEqual(570)
    expect(total).toBeLessThanOrEqual(630)
  })
})
