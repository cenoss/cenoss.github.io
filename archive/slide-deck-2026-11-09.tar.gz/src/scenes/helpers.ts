import * as THREE from 'three'

/** Mirrors the CSS tokens in styles/tokens.css: process inks on proof stock. */
export const PALETTE = {
  producer: 0xd9006f,
  gateway: 0x00a0e3,
  overprint: 0x2e3192,
  key: 0x231f20,
  muted: 0xa9ada9,
  stock: 0xe4e6e2,
}

export type Palette = Record<keyof typeof PALETTE, number>

export interface SceneContext {
  scene: THREE.Scene
  camera: THREE.PerspectiveCamera
  palette: Palette
  aspect: number
}

export interface SceneHandle {
  update(t: number, dt: number): void
  dispose(): void
}

export type SceneFactory = (ctx: SceneContext) => SceneHandle

export function solid(color: number, opacity = 1) {
  return new THREE.MeshBasicMaterial({ color, transparent: opacity < 1, opacity })
}

export function lines(color: number, opacity = 1) {
  return new THREE.LineBasicMaterial({ color, transparent: opacity < 1, opacity })
}

export function wire(color: number, opacity = 0.6) {
  return new THREE.MeshBasicMaterial({ color, wireframe: true, transparent: true, opacity })
}

/** Removes a group from the scene and frees every geometry and material under it. */
export function disposeGroup(scene: THREE.Scene, group: THREE.Object3D) {
  group.traverse((o) => {
    const m = o as THREE.Mesh
    m.geometry?.dispose?.()
    const mat = m.material as THREE.Material | THREE.Material[] | undefined
    if (Array.isArray(mat)) mat.forEach((x) => x.dispose())
    else mat?.dispose?.()
  })
  scene.remove(group)
}

export const easeInOut = (p: number) => (p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2)
export const frac = (x: number) => x - Math.floor(x)

/** Deterministic pseudo-random in [0,1) so scenes look the same on every run. */
export function rand(seed: number) {
  const x = Math.sin(seed * 127.1 + 311.7) * 43758.5453
  return x - Math.floor(x)
}
