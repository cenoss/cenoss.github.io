<script setup lang="ts">
import SlideShell from '../components/SlideShell.vue'
import TbdBadge from '../components/TbdBadge.vue'
import ThreeScene from '../components/ThreeScene.vue'
import { scenes } from '../scenes'
import { useI18n } from '../composables/i18n'
const { t } = useI18n()
const sections = ['o1', 'o2', 'o3', 'o4', 'o5', 'o6', 'o7', 'o8', 'o9']
const beats = [
  { k: 'v1', at: '0:00', len: 15 },
  { k: 'v2', at: '0:15', len: 20 },
  { k: 'v3', at: '0:35', len: 25 },
  { k: 'v4', at: '1:00', len: 25 },
  { k: 'v5', at: '1:25', len: 25 },
  { k: 'v6', at: '1:50', len: 10 },
]
</script>

<template>
  <SlideShell kicker="s12.kicker" title="s12.title">
    <div class="out">
      <ol v-stagger class="page">
        <li v-for="(s, i) in sections" :key="s" :class="{ wide: i === 0 || i === 8 }">
          <span class="page-n">{{ i + 1 }}</span>
          <span>{{ t(`s12.${s}`) }}</span>
        </li>
      </ol>
      <div class="video">
        <h3>{{ t('s12.v_h') }}</h3>
        <ol v-stagger class="beats">
          <li v-for="b in beats" :key="b.k" :style="{ flexGrow: b.len }">
            <span class="beat-at">{{ b.at }}</span>
            <span class="beat-bar" />
            <span class="beat-text">{{ t(`s12.${b.k}`) }}</span>
          </li>
        </ol>
        <p class="video-note">{{ t('s12.v_note') }}</p>
      </div>
    </div>
    <ThreeScene :scene="scenes.s12" :style="{ right: 0, bottom: 0, width: '42cqw', height: '18cqw' }" />
    <template #foot>
      <span>{{ t('s12.url') }}</span>
      <TbdBadge />
    </template>
  </SlideShell>
</template>

<style scoped>
.out {
  height: 100%;
  display: grid;
  grid-template-columns: 1fr 1fr;
  column-gap: 3cqw;
  align-content: start;
}
.page {
  --stagger-step: 70ms;
  display: grid;
  row-gap: 0.35cqw;
}
.page li {
  display: grid;
  grid-template-columns: 1.6cqw 1fr;
  column-gap: 0.8cqw;
  align-items: baseline;
  background: var(--tint);
  padding: 0.55cqw 0.9cqw;
  font-size: 1.2cqw;
  line-height: 1.3;
}
.page li.wide {
  background: var(--tint-2);
}
.page-n {
  font-family: var(--font-display);
  font-weight: 600;
  color: var(--muted);
}
.video {
  display: grid;
  align-content: start;
  row-gap: 1.2cqw;
}
.video h3 {
  animation: rise 560ms var(--ease-out) 900ms both;
  font-family: var(--font-display);
  font-weight: 700;
  font-size: var(--t-h3);
}
.beats {
  --stagger-base: 1100ms;
  --stagger-step: 140ms;
  display: flex;
  gap: 0.3cqw;
}
.beats li {
  display: grid;
  row-gap: 0.5cqw;
  min-width: 0;
  flex-basis: 0;
}
.beat-at {
  font-size: var(--t-foot);
  color: var(--muted);
  font-variant-numeric: tabular-nums;
}
.beat-bar {
  height: 0.6cqw;
  background: var(--key);
  transform-origin: left;
  animation: draw 500ms var(--ease-out) both;
  animation-delay: calc(var(--stagger-base) + var(--i, 0) * var(--stagger-step) + 150ms);
}
.beats li:last-child .beat-bar {
  background: var(--muted);
}
.beat-text {
  font-size: 1.05cqw;
  line-height: 1.25;
}
.video-note {
  animation: rise 500ms var(--ease-out) 2000ms both;
  font-size: var(--t-foot);
  color: var(--muted);
  line-height: 1.4;
}
</style>
