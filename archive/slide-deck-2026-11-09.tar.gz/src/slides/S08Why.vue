<script setup lang="ts">
import SlideShell from '../components/SlideShell.vue'
import TbdBadge from '../components/TbdBadge.vue'
import ThreeScene from '../components/ThreeScene.vue'
import { scenes } from '../scenes'
import { useI18n } from '../composables/i18n'
const { t } = useI18n()
const reasons = ['r1', 'r2', 'r3', 'r4']
</script>

<template>
  <SlideShell kicker="s8.kicker" title="s8.title">
    <div class="why">
      <ul v-stagger class="reasons">
        <li v-for="r in reasons" :key="r">
          <h3>{{ t(`s8.${r}_h`) }}</h3>
          <p>{{ t(`s8.${r}`) }}</p>
        </li>
      </ul>
    </div>
    <ThreeScene :scene="scenes.s8" :style="{ right: 0, bottom: 0, width: '40cqw', height: '18cqw' }" />
    <template #foot>
      <span>{{ t('s8.company') }}</span>
      <span class="sep" aria-hidden="true">|</span>
      <span>{{ t('s8.company_tbd') }} <TbdBadge /></span>
    </template>
  </SlideShell>
</template>

<style scoped>
.why {
  height: 100%;
  display: grid;
  align-content: start;
}
.reasons {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.6cqw 2.4cqw;
}
.reasons li {
  display: grid;
  row-gap: 0.5cqw;
  padding-left: 1.2cqw;
  border-left: 0.2cqw solid var(--key);
}
h3 {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: var(--t-h3);
}
p {
  font-size: 1.5cqw;
  line-height: 1.4;
}
.sep {
  color: var(--line);
}
</style>
