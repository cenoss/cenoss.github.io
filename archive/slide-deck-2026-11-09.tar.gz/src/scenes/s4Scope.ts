import * as THREE from 'three'
import { disposeGroup, lines, solid, wire, type SceneFactory } from './helpers'

/** A wireframe globe; a marker orbits a ring whose bright arc is the study window. */
export const s4Scope: SceneFactory = ({ scene, camera, palette }) => {
  const group = new THREE.Group()
  const globe = new THREE.Mesh(new THREE.IcosahedronGeometry(1.5, 2), wire(palette.muted, 0.35))
  group.add(globe)
  const ring = new THREE.Mesh(new THREE.TorusGeometry(2.3, 0.015, 8, 120), solid(palette.muted, 0.5))
  const arc = new THREE.Mesh(new THREE.TorusGeometry(2.3, 0.04, 8, 80, Math.PI * 1.25), solid(palette.gateway))
  const orbit = new THREE.Group()
  orbit.add(ring, arc)
  orbit.rotation.x = Math.PI / 2.6
  group.add(orbit)
  const marker = new THREE.Mesh(new THREE.SphereGeometry(0.12, 12, 12), solid(palette.producer))
  orbit.add(marker)
  const spoke = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3(2.3, 0, 0)]), lines(palette.producer, 0.5))
  orbit.add(spoke)
  scene.add(group)
  camera.position.set(0, 0.3, 7)
  camera.lookAt(0, 0, 0)

  return {
    update(t) {
      globe.rotation.y = t * 0.25
      globe.rotation.x = Math.sin(t * 0.2) * 0.2
      const a = t * 0.6
      marker.position.set(Math.cos(a) * 2.3, Math.sin(a) * 2.3, 0)
      spoke.rotation.z = a
      const inWindow = (a % (Math.PI * 2)) < Math.PI * 1.25
      ;(marker.material as THREE.MeshBasicMaterial).color.setHex(inWindow ? palette.producer : palette.muted)
    },
    dispose: () => disposeGroup(scene, group),
  }
}
