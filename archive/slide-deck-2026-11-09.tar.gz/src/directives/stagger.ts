import type { Directive } from 'vue'

/** Numbers direct children with `--i` so CSS can delay each one in sequence. */
export const stagger: Directive<HTMLElement> = {
  mounted(el) {
    el.classList.add('stagger')
    Array.from(el.children).forEach((child, i) => {
      ;(child as HTMLElement).style.setProperty('--i', String(i))
    })
  },
}
