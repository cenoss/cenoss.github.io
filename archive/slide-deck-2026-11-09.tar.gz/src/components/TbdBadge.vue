<script setup lang="ts">
import { useI18n } from '../composables/i18n'
const { t } = useI18n()
</script>

<template>
  <span class="tbd">{{ t('chrome.tbd') }}</span>
</template>

<style scoped>
.tbd {
  display: inline-block;
  font-size: 0.82em;
  font-weight: 600;
  line-height: 1;
  padding: 0.25em 0.45em;
  background: var(--tbd);
  color: var(--key);
  vertical-align: middle;
  white-space: nowrap;
}
</style>
