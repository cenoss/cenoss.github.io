<script setup lang="ts">
import SlideShell from '../components/SlideShell.vue'
import DiagramEmbed from '../components/DiagramEmbed.vue'
import TbdBadge from '../components/TbdBadge.vue'
import ThreeScene from '../components/ThreeScene.vue'
import { scenes } from '../scenes'
import { useI18n } from '../composables/i18n'
const { t } = useI18n()
const steps = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7']
const loops = ['l1', 'l2', 'l3']
</script>

<template>
  <SlideShell kicker="s10.kicker" title="s10.title">
    <div class="pipe">
      <ol v-stagger class="steps">
        <li v-for="(s, i) in steps" :key="s" :class="{ human: s === 'p4' }">
          <span class="step-n">{{ i + 1 }}</span>
          <span class="step-text">{{ t(`s10.${s}`) }}</span>
        </li>
      </ol>
      <div class="lower">
        <ul v-stagger class="loops">
          <li v-for="l in loops" :key="l">{{ t(`s10.${l}`) }}</li>
          <li class="weekly">{{ t('s10.weekly') }} <TbdBadge /></li>
        </ul>
        <DiagramEmbed src="/diagrams/B-flow.svg" alt="Diagram B: AI agent workflow">
          {{ t('s10.caption') }}
        </DiagramEmbed>
      </div>
    </div>
    <ThreeScene :scene="scenes.s10" :style="{ left: 0, bottom: 0, width: '44cqw', height: '12cqw' }" />
    <template #foot>{{ t('s10.tools') }}</template>
  </SlideShell>
</template>

<style scoped>
.pipe {
  height: 100%;
  display: grid;
  grid-template-rows: auto 1fr;
  row-gap: 1.6cqw;
  min-height: 0;
}
.steps {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  column-gap: 0.6cqw;
  counter-reset: step;
}
.steps {
  --stagger-step: 130ms;
}
.steps li {
  position: relative;
  display: grid;
  row-gap: 0.5cqw;
  padding-top: 0.7cqw;
  font-size: 1.2cqw;
  line-height: 1.3;
}
.steps li::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 0.3cqw;
  background: var(--muted);
  transform-origin: left;
  animation: draw 520ms var(--ease-out) both;
  animation-delay: calc(var(--stagger-base) + var(--i, 0) * var(--stagger-step) + 120ms);
}
.steps li.human::before {
  height: 0.6cqw;
  background: var(--key);
}
.steps li.human .step-text {
  font-weight: 600;
}
.step-n {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: var(--t-h3);
  line-height: 1;
  color: var(--muted);
}
.lower {
  display: grid;
  grid-template-columns: 1fr 1fr;
  column-gap: 2.4cqw;
  min-height: 0;
}
.loops {
  --stagger-base: 1400ms;
  display: grid;
  align-content: start;
  row-gap: 0.8cqw;
  font-size: 1.3cqw;
  line-height: 1.4;
}
.loops li {
  padding-left: 1.1cqw;
  border-left: 0.2cqw solid var(--key);
}
.loops li.weekly {
  border-left-color: var(--muted);
  color: var(--muted);
  margin-top: 0.6cqw;
}
</style>
