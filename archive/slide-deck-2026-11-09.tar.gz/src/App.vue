<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref, watch } from 'vue'
import en from './content/en.json'
import zh from './content/zh-TW.json'
import { provideI18n } from './composables/i18n'
import { keyToAction, useDeck } from './composables/useDeck'
import { slides } from './content/slides'
import DeckChrome from './components/DeckChrome.vue'
import NotesPanel from './components/NotesPanel.vue'

let storage: Storage | null = null
try {
  storage = window.localStorage
} catch {
  storage = null
}

const i18n = provideI18n({ en, 'zh-TW': zh }, storage)
const deck = useDeck(slides.length)
const notesOpen = ref(false)
const current = computed(() => slides[deck.index.value])

watch(
  i18n.lang,
  (l) => {
    document.documentElement.lang = l
  },
  { immediate: true },
)

function toggleFullscreen() {
  if (document.fullscreenElement) void document.exitFullscreen()
  else void document.documentElement.requestFullscreen()
}

function onKey(e: KeyboardEvent) {
  if (e.metaKey || e.ctrlKey || e.altKey) return
  const action = keyToAction(e.key)
  if (!action) return
  switch (action) {
    case 'next':
      deck.next()
      break
    case 'prev':
      deck.prev()
      break
    case 'first':
      deck.first()
      break
    case 'last':
      deck.last()
      break
    case 'lang':
      i18n.toggle()
      break
    case 'notes':
      notesOpen.value = !notesOpen.value
      break
    case 'fullscreen':
      toggleFullscreen()
      break
    case 'escape':
      notesOpen.value = false
      break
  }
  e.preventDefault()
}

onMounted(() => {
  window.addEventListener('keydown', onKey)
  window.addEventListener('hashchange', deck.syncFromHash)
})
onUnmounted(() => {
  window.removeEventListener('keydown', onKey)
  window.removeEventListener('hashchange', deck.syncFromHash)
})
</script>

<template>
  <div class="stage-wrap">
    <main class="stage">
      <Transition :name="`slide-${deck.direction.value}`">
        <component :is="current.component" :key="current.id" />
      </Transition>
      <NotesPanel v-if="notesOpen" :notes-key="current.notesKey" :budget-sec="current.budgetSec" />
      <DeckChrome :index="deck.index.value" :total="deck.total" @toggle-lang="i18n.toggle()" />
    </main>
  </div>
</template>
