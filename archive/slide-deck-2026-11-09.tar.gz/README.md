# W10 pitch deck: ETtoday platform strategy (Group 4)

Keyboard-driven slide deck for the 10-minute W10 pitch, built from `G4_ETtoday_TP_Proposal.md` and the three diagrams in `diagrams/`. Vite + Vue 3, no server, no keys, system fonts only (works offline).

## Run

```bash
npm install
npm run dev        # http://localhost:5173
npm test           # Vitest
npm run build      # static output in dist/
```

## On stage

| Key | Action |
| --- | --- |
| → · Space · PageDown | next slide (clickers send PageDown) |
| ← · PageUp | previous slide |
| Home · End | first / last slide |
| L | switch language (zh-TW / en) |
| N | speaker notes with the slide's time budget |
| F | fullscreen |
| Esc | close notes or the diagram zoom |

Slides deep-link by hash, for example `/#/7`. Click a diagram to zoom; Esc closes it.

Each slide plays one entrance sequence (kicker, title, then body items in order; numbers count up, rules and bars draw in). Slide changes move in the direction of travel. All motion is disabled when the OS asks for reduced motion.

## Looping 3D scenes

Every slide after the title carries a looping three.js scene tied to its subject (yearly bars crossing the profit line, news particles flowing from producers to gateways, a globe with the 2025–2026 window, the six-question ring, the three lenses as rings, the framework pulse, the leader and its orbiting rivals, scanned data layers, the pipeline with its feedback loop, chaos becoming a table, a live dashboard screen, three orbiting pairs on a week ring, and a breathing network). Scenes live in `src/scenes/`, one file each, registered in `src/scenes/index.ts` by slide id; `ThreeScene.vue` owns the canvas, resize, pause-when-hidden, reduced-motion fallback (one static frame) and disposal on slide change. A scene is a factory `(ctx) => { update(t, dt), dispose() }`; `npm test` builds, animates and disposes every registered scene.

## Visual system

The deck is styled as a press sheet: black ink on grey proof stock, plus process colours that each carry one meaning. Magenta means producers (the newsroom layer). Cyan means distribution platforms. Overprint blue, where the two plates meet, means ETtoday, which sits in both layers. Process yellow marks only unverified items (the TBD highlight). Anything else stays black. Tokens live in `src/styles/tokens.css`, and `PALETTE` in `src/scenes/helpers.ts` mirrors them for the 3D scenes. Use the `-ink` variants (`--producer-ink`, `--gateway-ink`) for small coloured text. Headlines use Charter with Songti TC; body text uses Seravek with PingFang TC. All four ship with macOS, so the deck stays offline.

## Edit motion

Add `v-stagger` to any container to make its children rise one after another; tune `--stagger-base` and `--stagger-step` on that container. Keyframes live in `src/styles/base.css`.

## Edit content

Every visible string lives in `src/content/en.json` and `src/content/zh-TW.json` under the same keys; `npm test` fails if the two files drift. Slide order and time budgets are in `src/content/slides.ts`. Member names are the `__` placeholders under `s1.members` and `s13.names`.
