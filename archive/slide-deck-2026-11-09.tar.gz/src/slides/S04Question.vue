<script setup lang="ts">
import SlideShell from '../components/SlideShell.vue'
import ThreeScene from '../components/ThreeScene.vue'
import { scenes } from '../scenes'
import { useI18n } from '../composables/i18n'
const { t } = useI18n()
const scope = ['s4.scope1', 's4.scope2', 's4.scope3', 's4.scope4', 's4.scope5']
</script>

<template>
  <SlideShell kicker="s4.kicker" title="s4.title">
    <div class="rq">
      <p class="lead">{{ t('s4.detail') }}</p>
      <div class="scope">
        <h3>{{ t('s4.scope_h') }}</h3>
        <ul v-stagger class="scope-list">
          <li v-for="k in scope" :key="k" :class="{ excluded: k === 's4.scope5' }">{{ t(k) }}</li>
        </ul>
      </div>
    </div>
    <ThreeScene :scene="scenes.s4" :style="{ left: 0, bottom: 0, width: '40cqw', height: '22cqw' }" />
  </SlideShell>
</template>

<style scoped>
.rq {
  height: 100%;
  display: grid;
  grid-template-columns: 0.9fr 1.1fr;
  column-gap: 3cqw;
  align-content: start;
}
.lead {
  animation: rise 560ms var(--ease-out) var(--stagger-base) both;
  font-size: var(--t-lead);
  line-height: 1.35;
  color: var(--muted);
  max-width: 34ch;
}
.scope h3 {
  animation: rise 560ms var(--ease-out) var(--stagger-base) both;
  font-family: var(--font-display);
  font-weight: 700;
  font-size: var(--t-h3);
  margin-bottom: 0.8cqw;
}
.scope-list {
  --stagger-base: 560ms;
}
.scope-list li {
  padding: 0.7cqw 0 0.7cqw 1.2cqw;
  border-left: 0.2cqw solid var(--key);
  line-height: 1.35;
}
.scope-list li + li {
  margin-top: 0.3cqw;
}
.scope-list li.excluded {
  border-left-color: var(--muted);
  color: var(--muted);
}
</style>
