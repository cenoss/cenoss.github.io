<script setup lang="ts">
import { onBeforeUnmount, onMounted, ref } from 'vue'
import * as THREE from 'three'
import { PALETTE, type Palette, type SceneFactory, type SceneHandle } from '../scenes/helpers'

const props = withDefaults(
  defineProps<{
    scene: SceneFactory
    opacity?: number
    /** colour overrides for scenes drawn on a non-stock ground, e.g. { key: PALETTE.stock } on overprint */
    palette?: Partial<Palette>
  }>(),
  { opacity: 1, palette: () => ({}) },
)

const host = ref<HTMLElement | null>(null)
let renderer: THREE.WebGLRenderer | null = null
let handle: SceneHandle | null = null
let observer: ResizeObserver | null = null
let raf = 0
let running = false

onMounted(() => {
  const el = host.value
  if (!el) return
  try {
    renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'low-power' })
  } catch {
    renderer = null
    return
  }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2))
  renderer.setClearColor(0x000000, 0)
  el.appendChild(renderer.domElement)

  const scene = new THREE.Scene()
  const camera = new THREE.PerspectiveCamera(40, 1, 0.1, 100)
  const fit = () => {
    const w = el.clientWidth || 1
    const h = el.clientHeight || 1
    renderer!.setSize(w, h, false)
    camera.aspect = w / h
    camera.updateProjectionMatrix()
  }
  fit()
  handle = props.scene({ scene, camera, palette: { ...PALETTE, ...props.palette }, aspect: camera.aspect })

  const reduced = typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches
  const start = performance.now()
  let last = start
  const frame = (now: number) => {
    if (running) raf = requestAnimationFrame(frame)
    // the first rAF timestamp can predate the mount-time clock reading
    const t = Math.max(0, (now - start) / 1000)
    handle!.update(t, Math.max(0, (now - last) / 1000))
    last = now
    renderer!.render(scene, camera)
  }
  if (reduced) {
    handle.update(2.5, 0)
    renderer.render(scene, camera)
  } else {
    running = true
    raf = requestAnimationFrame(frame)
  }

  if (typeof ResizeObserver !== 'undefined') {
    observer = new ResizeObserver(fit)
    observer.observe(el)
  }
  document.addEventListener('visibilitychange', onVisibility)

  function onVisibility() {
    if (reduced || !renderer) return
    if (document.hidden) {
      running = false
      cancelAnimationFrame(raf)
    } else if (!running) {
      running = true
      last = performance.now()
      raf = requestAnimationFrame(frame)
    }
  }
  cleanup = () => {
    document.removeEventListener('visibilitychange', onVisibility)
    running = false
    cancelAnimationFrame(raf)
    observer?.disconnect()
    handle?.dispose()
    renderer?.dispose()
    renderer?.domElement.remove()
  }
})

let cleanup = () => {}
onBeforeUnmount(() => cleanup())
</script>

<template>
  <!-- opacity goes on the canvas: the host's entrance animation would override an inline opacity -->
  <div ref="host" class="scene" :style="{ '--scene-opacity': opacity }" aria-hidden="true" />
</template>

<style scoped>
.scene {
  position: absolute;
  z-index: -1;
  pointer-events: none;
  overflow: hidden;
  animation: pop 900ms var(--ease-out) 300ms both;
}
.scene :deep(canvas) {
  display: block;
  width: 100%;
  height: 100%;
  opacity: var(--scene-opacity, 1);
}
</style>
