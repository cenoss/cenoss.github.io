import * as THREE from 'three'
import { disposeGroup, lines, solid, type SceneFactory } from './helpers'

/** A turning screen with eight live dashboard bars and a play mark. */
export const s12Output: SceneFactory = ({ scene, camera, palette }) => {
  const group = new THREE.Group()
  const w = 4.2
  const h = 2.5
  const frame = new THREE.LineLoop(
    new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(-w / 2, -h / 2, 0),
      new THREE.Vector3(w / 2, -h / 2, 0),
      new THREE.Vector3(w / 2, h / 2, 0),
      new THREE.Vector3(-w / 2, h / 2, 0),
    ]),
    lines(palette.key, 0.8),
  )
  group.add(frame)
  const bars = Array.from({ length: 8 }, (_, i) => {
    const bar = new THREE.Mesh(new THREE.BoxGeometry(0.3, 1, 0.12), solid(i % 3 === 0 ? palette.producer : palette.gateway))
    bar.position.x = -w / 2 + 0.5 + i * 0.46
    group.add(bar)
    return bar
  })
  const play = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.4, 3), solid(palette.producer))
  play.rotation.z = -Math.PI / 2
  play.position.set(w / 2 - 0.5, h / 2 - 0.45, 0.05)
  group.add(play)
  scene.add(group)
  camera.position.set(0, 0.4, 7)
  camera.lookAt(0, 0, 0)

  return {
    update(t) {
      group.rotation.y = Math.sin(t * 0.4) * 0.55
      group.rotation.x = Math.sin(t * 0.25) * 0.12
      bars.forEach((b, i) => {
        const v = 0.5 + 0.45 * Math.sin(t * 1.3 + i * 0.9) + 0.25 * Math.sin(t * 2.1 + i)
        const height = Math.max(0.15, v * 1.5)
        b.scale.y = height
        b.position.y = -h / 2 + 0.3 + height / 2
      })
      play.scale.setScalar(1 + 0.15 * Math.sin(t * 3))
    },
    dispose: () => disposeGroup(scene, group),
  }
}
